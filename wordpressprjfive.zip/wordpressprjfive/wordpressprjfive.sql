-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2018 at 03:15 AM
-- Server version: 5.6.17-log
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wordpressprjfive`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-07-01 01:04:39', '2018-07-01 01:04:39', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=311 ;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/wordpressprjfive', 'yes'),
(2, 'home', 'http://localhost/wordpressprjfive', 'yes'),
(3, 'blogname', 'Republic of the union of Myanmar', 'yes'),
(4, 'blogdescription', 'Welcome from MYANMAR', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'hninminseok@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/index.php/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:90:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:57:"index.php/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:52:"index.php/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"index.php/category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:45:"index.php/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:27:"index.php/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:54:"index.php/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:49:"index.php/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:30:"index.php/tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:42:"index.php/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:24:"index.php/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:55:"index.php/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:50:"index.php/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:31:"index.php/type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:43:"index.php/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:25:"index.php/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:42:"index.php/feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:37:"index.php/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:18:"index.php/embed/?$";s:21:"index.php?&embed=true";s:30:"index.php/page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:37:"index.php/comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=8&cpage=$matches[1]";s:51:"index.php/comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:46:"index.php/comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:27:"index.php/comments/embed/?$";s:21:"index.php?&embed=true";s:54:"index.php/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:49:"index.php/search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:30:"index.php/search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:42:"index.php/search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:24:"index.php/search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:57:"index.php/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:52:"index.php/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:33:"index.php/author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:45:"index.php/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:27:"index.php/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:79:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:55:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:49:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:66:"index.php/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:42:"index.php/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:54:"index.php/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:36:"index.php/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:53:"index.php/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:48:"index.php/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:29:"index.php/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:41:"index.php/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:23:"index.php/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:68:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:78:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:98:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:74:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:63:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:87:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:75:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:71:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:57:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:67:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:87:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:63:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:48:"index.php/([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:37:"index.php/.?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"index.php/.?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"index.php/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"index.php/.?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"index.php/(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:30:"index.php/(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:50:"index.php/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:45:"index.php/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:38:"index.php/(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:45:"index.php/(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:34:"index.php/(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:57:"google-language-translator/google-language-translator.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'twentyseventeen', 'yes'),
(41, 'stylesheet', 'twentyseventeen', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:6:{i:1;a:0:{}s:12:"_multiwidget";i:1;i:2;a:2:{s:5:"title";s:7:"Find Us";s:4:"text";s:200:"<p><strong>Address</strong><br />123 Main Street<br />New York, NY 10001</p><p><strong>Hours</strong><br />Monday&mdash;Friday: 9:00AM&ndash;5:00PM<br />Saturday &amp; Sunday: 11:00AM&ndash;3:00PM</p>";}i:3;a:2:{s:5:"title";s:15:"About This Site";s:4:"text";s:85:"This may be a good place to introduce yourself and your site or include some credits.";}i:4;a:2:{s:5:"title";s:7:"Find Us";s:4:"text";s:200:"<p><strong>Address</strong><br />123 Main Street<br />New York, NY 10001</p><p><strong>Hours</strong><br />Monday&mdash;Friday: 9:00AM&ndash;5:00PM<br />Saturday &amp; Sunday: 11:00AM&ndash;3:00PM</p>";}i:5;a:2:{s:5:"title";s:15:"About This Site";s:4:"text";s:85:"This may be a good place to introduce yourself and your site or include some credits.";}}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '11', 'yes'),
(84, 'page_on_front', '8', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '29', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:4:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;i:3;a:1:{s:5:"title";s:6:"Search";}i:4;a:1:{s:5:"title";s:6:"Search";}}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:6:"text-2";i:1;s:8:"search-3";i:2;s:6:"text-3";}s:9:"sidebar-2";a:1:{i:0;s:6:"text-4";}s:9:"sidebar-3";a:2:{i:0;s:6:"text-5";i:1;s:8:"search-4";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'cron', 'a:5:{i:1537146281;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1537146282;a:2:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1537146358;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1537182664;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(105, 'theme_mods_twentyseventeen', 'a:12:{s:18:"custom_css_post_id";i:93;s:18:"nav_menu_locations";a:2:{s:3:"top";i:2;s:6:"social";i:2;}s:7:"panel_1";i:12;s:7:"panel_2";i:9;s:7:"panel_3";i:11;s:7:"panel_4";i:10;s:16:"header_textcolor";s:6:"f49922";s:11:"colorscheme";s:4:"dark";s:11:"custom_logo";i:32;s:12:"header_image";s:79:"http://localhost/wordpressprjfive/wp-content/uploads/2018/07/cropped-myan15.jpg";s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:97;s:3:"url";s:79:"http://localhost/wordpressprjfive/wp-content/uploads/2018/07/cropped-myan15.jpg";s:13:"thumbnail_url";s:79:"http://localhost/wordpressprjfive/wp-content/uploads/2018/07/cropped-myan15.jpg";s:6:"height";i:1336;s:5:"width";i:2000;}s:11:"page_layout";s:10:"two-column";}', 'yes'),
(109, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:4:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.7.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.7.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.9.7-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.9.7-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.9.7";s:7:"version";s:5:"4.9.7";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.7.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.7.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.9.7-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.9.7-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.9.7";s:7:"version";s:5:"4.9.7";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";s:9:"new_files";s:1:"1";}i:2;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.7.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.7.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.8.7-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.8.7-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.8.7";s:7:"version";s:5:"4.8.7";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";s:9:"new_files";s:1:"1";}i:3;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:60:"https://downloads.wordpress.org/release/wordpress-4.7.11.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:60:"https://downloads.wordpress.org/release/wordpress-4.7.11.zip";s:10:"no_content";s:71:"https://downloads.wordpress.org/release/wordpress-4.7.11-no-content.zip";s:11:"new_bundled";s:72:"https://downloads.wordpress.org/release/wordpress-4.7.11-new-bundled.zip";s:7:"partial";s:70:"https://downloads.wordpress.org/release/wordpress-4.7.11-partial-5.zip";s:8:"rollback";s:71:"https://downloads.wordpress.org/release/wordpress-4.7.11-rollback-5.zip";}s:7:"current";s:6:"4.7.11";s:7:"version";s:6:"4.7.11";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:5:"4.7.5";s:9:"new_files";s:0:"";}}s:12:"last_checked";i:1537112961;s:15:"version_checked";s:5:"4.7.5";s:12:"translations";a:0:{}}', 'no'),
(115, 'can_compress_scripts', '1', 'no'),
(131, 'current_theme', 'Twenty Seventeen', 'yes'),
(132, 'theme_mods_vivita', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1530692586;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:12:"sidebar-left";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"sidebar-right";a:0:{}s:13:"sidebar-promo";a:0:{}s:15:"sidebar-front-a";N;s:15:"sidebar-front-b";N;s:14:"sidebar-footer";N;}}}', 'yes'),
(133, 'theme_switched', '', 'yes'),
(151, 'theme_mods_twentyfifteen', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1530692726;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(153, '_transient_twentyfifteen_categories', '1', 'yes'),
(154, '_site_transient_timeout_wporg_theme_feature_list', '1530703516', 'no'),
(155, '_site_transient_wporg_theme_feature_list', 'a:0:{}', 'no'),
(156, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1537112962;s:7:"checked";a:4:{s:13:"twentyfifteen";s:3:"1.7";s:15:"twentyseventeen";s:3:"1.2";s:13:"twentysixteen";s:3:"1.3";s:6:"vivita";s:5:"1.0.6";}s:8:"response";a:3:{s:13:"twentyfifteen";a:4:{s:5:"theme";s:13:"twentyfifteen";s:11:"new_version";s:3:"2.0";s:3:"url";s:43:"https://wordpress.org/themes/twentyfifteen/";s:7:"package";s:59:"https://downloads.wordpress.org/theme/twentyfifteen.2.0.zip";}s:15:"twentyseventeen";a:4:{s:5:"theme";s:15:"twentyseventeen";s:11:"new_version";s:3:"1.6";s:3:"url";s:45:"https://wordpress.org/themes/twentyseventeen/";s:7:"package";s:61:"https://downloads.wordpress.org/theme/twentyseventeen.1.6.zip";}s:13:"twentysixteen";a:4:{s:5:"theme";s:13:"twentysixteen";s:11:"new_version";s:3:"1.5";s:3:"url";s:43:"https://wordpress.org/themes/twentysixteen/";s:7:"package";s:59:"https://downloads.wordpress.org/theme/twentysixteen.1.5.zip";}}s:12:"translations";a:0:{}}', 'no'),
(158, 'nav_menu_options', 'a:1:{s:8:"auto_add";a:0:{}}', 'yes'),
(162, 'recently_activated', 'a:0:{}', 'yes'),
(187, 'category_children', 'a:0:{}', 'yes'),
(220, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1530923818', 'no'),
(221, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'O:8:"stdClass":100:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";i:4475;}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";i:2868;}s:4:"post";a:3:{s:4:"name";s:4:"post";s:4:"slug";s:4:"post";s:5:"count";i:2568;}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";i:2439;}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";i:1875;}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";i:1663;}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";i:1656;}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";i:1458;}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";i:1400;}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";i:1393;}s:8:"facebook";a:3:{s:4:"name";s:8:"facebook";s:4:"slug";s:8:"facebook";s:5:"count";i:1391;}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";i:1323;}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";i:1286;}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";i:1222;}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";i:1113;}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";i:1067;}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";i:1028;}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";i:1027;}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";i:905;}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";i:884;}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";i:829;}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";i:806;}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";i:804;}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";i:724;}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";i:694;}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";i:694;}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";i:686;}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";i:676;}s:6:"slider";a:3:{s:4:"name";s:6:"slider";s:4:"slug";s:6:"slider";s:5:"count";i:664;}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";i:659;}s:9:"analytics";a:3:{s:4:"name";s:9:"analytics";s:4:"slug";s:9:"analytics";s:5:"count";i:656;}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";i:642;}s:10:"e-commerce";a:3:{s:4:"name";s:10:"e-commerce";s:4:"slug";s:10:"e-commerce";s:5:"count";i:642;}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";i:641;}s:6:"search";a:3:{s:4:"name";s:6:"search";s:4:"slug";s:6:"search";s:5:"count";i:611;}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";i:611;}s:4:"ajax";a:3:{s:4:"name";s:4:"ajax";s:4:"slug";s:4:"ajax";s:5:"count";i:607;}s:4:"form";a:3:{s:4:"name";s:4:"form";s:4:"slug";s:4:"form";s:5:"count";i:604;}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";i:601;}s:4:"menu";a:3:{s:4:"name";s:4:"menu";s:4:"slug";s:4:"menu";s:5:"count";i:592;}s:5:"embed";a:3:{s:4:"name";s:5:"embed";s:4:"slug";s:5:"embed";s:5:"count";i:570;}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";i:549;}s:3:"css";a:3:{s:4:"name";s:3:"css";s:4:"slug";s:3:"css";s:5:"count";i:542;}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";i:538;}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";i:526;}s:5:"share";a:3:{s:4:"name";s:5:"share";s:4:"slug";s:5:"share";s:5:"count";i:524;}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";i:510;}s:5:"theme";a:3:{s:4:"name";s:5:"theme";s:4:"slug";s:5:"theme";s:5:"count";i:508;}s:6:"editor";a:3:{s:4:"name";s:6:"editor";s:4:"slug";s:6:"editor";s:5:"count";i:505;}s:10:"responsive";a:3:{s:4:"name";s:10:"responsive";s:4:"slug";s:10:"responsive";s:5:"count";i:504;}s:9:"dashboard";a:3:{s:4:"name";s:9:"dashboard";s:4:"slug";s:9:"dashboard";s:5:"count";i:494;}s:6:"custom";a:3:{s:4:"name";s:6:"custom";s:4:"slug";s:6:"custom";s:5:"count";i:488;}s:12:"contact-form";a:3:{s:4:"name";s:12:"contact form";s:4:"slug";s:12:"contact-form";s:5:"count";i:485;}s:10:"categories";a:3:{s:4:"name";s:10:"categories";s:4:"slug";s:10:"categories";s:5:"count";i:483;}s:3:"ads";a:3:{s:4:"name";s:3:"ads";s:4:"slug";s:3:"ads";s:5:"count";i:475;}s:9:"affiliate";a:3:{s:4:"name";s:9:"affiliate";s:4:"slug";s:9:"affiliate";s:5:"count";i:475;}s:6:"button";a:3:{s:4:"name";s:6:"button";s:4:"slug";s:6:"button";s:5:"count";i:459;}s:4:"tags";a:3:{s:4:"name";s:4:"tags";s:4:"slug";s:4:"tags";s:5:"count";i:457;}s:4:"user";a:3:{s:4:"name";s:4:"user";s:4:"slug";s:4:"user";s:5:"count";i:447;}s:7:"contact";a:3:{s:4:"name";s:7:"contact";s:4:"slug";s:7:"contact";s:5:"count";i:440;}s:3:"api";a:3:{s:4:"name";s:3:"api";s:4:"slug";s:3:"api";s:5:"count";i:434;}s:6:"mobile";a:3:{s:4:"name";s:6:"mobile";s:4:"slug";s:6:"mobile";s:5:"count";i:434;}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";i:421;}s:5:"users";a:3:{s:4:"name";s:5:"users";s:4:"slug";s:5:"users";s:5:"count";i:417;}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";i:415;}s:9:"slideshow";a:3:{s:4:"name";s:9:"slideshow";s:4:"slug";s:9:"slideshow";s:5:"count";i:414;}s:6:"events";a:3:{s:4:"name";s:6:"events";s:4:"slug";s:6:"events";s:5:"count";i:409;}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";i:404;}s:7:"payment";a:3:{s:4:"name";s:7:"payment";s:4:"slug";s:7:"payment";s:5:"count";i:404;}s:10:"statistics";a:3:{s:4:"name";s:10:"statistics";s:4:"slug";s:10:"statistics";s:5:"count";i:388;}s:10:"navigation";a:3:{s:4:"name";s:10:"navigation";s:4:"slug";s:10:"navigation";s:5:"count";i:387;}s:4:"news";a:3:{s:4:"name";s:4:"news";s:4:"slug";s:4:"news";s:5:"count";i:369;}s:8:"calendar";a:3:{s:4:"name";s:8:"calendar";s:4:"slug";s:8:"calendar";s:5:"count";i:365;}s:10:"shortcodes";a:3:{s:4:"name";s:10:"shortcodes";s:4:"slug";s:10:"shortcodes";s:5:"count";i:363;}s:15:"payment-gateway";a:3:{s:4:"name";s:15:"payment gateway";s:4:"slug";s:15:"payment-gateway";s:5:"count";i:361;}s:5:"popup";a:3:{s:4:"name";s:5:"popup";s:4:"slug";s:5:"popup";s:5:"count";i:360;}s:9:"marketing";a:3:{s:4:"name";s:9:"marketing";s:4:"slug";s:9:"marketing";s:5:"count";i:354;}s:4:"chat";a:3:{s:4:"name";s:4:"chat";s:4:"slug";s:4:"chat";s:5:"count";i:352;}s:7:"plugins";a:3:{s:4:"name";s:7:"plugins";s:4:"slug";s:7:"plugins";s:5:"count";i:348;}s:12:"social-media";a:3:{s:4:"name";s:12:"social media";s:4:"slug";s:12:"social-media";s:5:"count";i:348;}s:10:"newsletter";a:3:{s:4:"name";s:10:"newsletter";s:4:"slug";s:10:"newsletter";s:5:"count";i:344;}s:9:"multisite";a:3:{s:4:"name";s:9:"multisite";s:4:"slug";s:9:"multisite";s:5:"count";i:342;}s:4:"code";a:3:{s:4:"name";s:4:"code";s:4:"slug";s:4:"code";s:5:"count";i:342;}s:3:"url";a:3:{s:4:"name";s:3:"url";s:4:"slug";s:3:"url";s:5:"count";i:335;}s:4:"meta";a:3:{s:4:"name";s:4:"meta";s:4:"slug";s:4:"meta";s:5:"count";i:335;}s:4:"list";a:3:{s:4:"name";s:4:"list";s:4:"slug";s:4:"list";s:5:"count";i:334;}s:8:"redirect";a:3:{s:4:"name";s:8:"redirect";s:4:"slug";s:8:"redirect";s:5:"count";i:327;}s:5:"forms";a:3:{s:4:"name";s:5:"forms";s:4:"slug";s:5:"forms";s:5:"count";i:320;}s:6:"simple";a:3:{s:4:"name";s:6:"simple";s:4:"slug";s:6:"simple";s:5:"count";i:307;}s:11:"advertising";a:3:{s:4:"name";s:11:"advertising";s:4:"slug";s:11:"advertising";s:5:"count";i:307;}s:16:"custom-post-type";a:3:{s:4:"name";s:16:"custom post type";s:4:"slug";s:16:"custom-post-type";s:5:"count";i:306;}s:3:"tag";a:3:{s:4:"name";s:3:"tag";s:4:"slug";s:3:"tag";s:5:"count";i:303;}s:7:"adsense";a:3:{s:4:"name";s:7:"adsense";s:4:"slug";s:7:"adsense";s:5:"count";i:301;}s:4:"html";a:3:{s:4:"name";s:4:"html";s:4:"slug";s:4:"html";s:5:"count";i:301;}s:11:"performance";a:3:{s:4:"name";s:11:"performance";s:4:"slug";s:11:"performance";s:5:"count";i:301;}s:12:"notification";a:3:{s:4:"name";s:12:"notification";s:4:"slug";s:12:"notification";s:5:"count";i:298;}s:8:"tracking";a:3:{s:4:"name";s:8:"tracking";s:4:"slug";s:8:"tracking";s:5:"count";i:297;}s:16:"google-analytics";a:3:{s:4:"name";s:16:"google analytics";s:4:"slug";s:16:"google-analytics";s:5:"count";i:295;}s:6:"author";a:3:{s:4:"name";s:6:"author";s:4:"slug";s:6:"author";s:5:"count";i:293;}s:8:"lightbox";a:3:{s:4:"name";s:8:"lightbox";s:4:"slug";s:8:"lightbox";s:5:"count";i:289;}}', 'no'),
(225, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1537112961;s:7:"checked";a:3:{s:19:"akismet/akismet.php";s:5:"3.3.2";s:57:"google-language-translator/google-language-translator.php";s:6:"5.0.48";s:9:"hello.php";s:3:"1.6";}s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":12:{s:2:"id";s:21:"w.org/plugins/akismet";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"4.0.8";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.4.0.8.zip";s:5:"icons";a:2:{s:2:"2x";s:59:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272";s:2:"1x";s:59:"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272";}s:7:"banners";a:1:{s:2:"1x";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.9.6";s:12:"requires_php";b:0;s:13:"compatibility";O:8:"stdClass":0:{}}}s:12:"translations";a:0:{}s:9:"no_update";a:2:{s:57:"google-language-translator/google-language-translator.php";O:8:"stdClass":9:{s:2:"id";s:40:"w.org/plugins/google-language-translator";s:4:"slug";s:26:"google-language-translator";s:6:"plugin";s:57:"google-language-translator/google-language-translator.php";s:11:"new_version";s:6:"5.0.48";s:3:"url";s:57:"https://wordpress.org/plugins/google-language-translator/";s:7:"package";s:76:"https://downloads.wordpress.org/plugin/google-language-translator.5.0.48.zip";s:5:"icons";a:2:{s:2:"2x";s:79:"https://ps.w.org/google-language-translator/assets/icon-256x256.png?rev=1012896";s:2:"1x";s:79:"https://ps.w.org/google-language-translator/assets/icon-256x256.png?rev=1012896";}s:7:"banners";a:2:{s:2:"2x";s:82:"https://ps.w.org/google-language-translator/assets/banner-1544x500.png?rev=1632425";s:2:"1x";s:81:"https://ps.w.org/google-language-translator/assets/banner-772x250.png?rev=1632425";}s:11:"banners_rtl";a:0:{}}s:9:"hello.php";O:8:"stdClass":9:{s:2:"id";s:25:"w.org/plugins/hello-dolly";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";s:5:"icons";a:2:{s:2:"2x";s:63:"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907";s:2:"1x";s:63:"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907";}s:7:"banners";a:1:{s:2:"1x";s:65:"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342";}s:11:"banners_rtl";a:0:{}}}}', 'no'),
(226, 'googlelanguagetranslator_active', '1', 'yes'),
(227, 'googlelanguagetranslator_language', 'en', 'yes'),
(228, 'googlelanguagetranslator_flags', '1', 'yes'),
(229, 'language_display_settings', 'a:8:{s:5:"zh-TW";s:1:"1";s:2:"en";s:1:"1";s:2:"fr";s:1:"1";s:2:"de";s:1:"1";s:2:"jw";s:1:"1";s:2:"ko";s:1:"1";s:2:"my";s:1:"1";s:2:"es";s:1:"1";}', 'yes'),
(230, 'googlelanguagetranslator_translatebox', 'yes', 'yes'),
(231, 'googlelanguagetranslator_display', 'Vertical', 'yes'),
(232, 'googlelanguagetranslator_toolbar', 'Yes', 'yes'),
(233, 'googlelanguagetranslator_showbranding', 'Yes', 'yes'),
(234, 'googlelanguagetranslator_flags_alignment', 'flags_right', 'yes'),
(235, 'googlelanguagetranslator_analytics', '', 'yes'),
(236, 'googlelanguagetranslator_analytics_id', '', 'yes'),
(237, 'googlelanguagetranslator_css', '', 'yes'),
(238, 'googlelanguagetranslator_multilanguage', '', 'yes'),
(239, 'googlelanguagetranslator_floating_widget', 'yes', 'yes'),
(240, 'googlelanguagetranslator_flag_size', '18', 'yes'),
(241, 'googlelanguagetranslator_flags_order', '', 'yes'),
(242, 'googlelanguagetranslator_english_flag_choice', 'us_flag', 'yes'),
(243, 'googlelanguagetranslator_spanish_flag_choice', 'spanish_flag', 'yes'),
(244, 'googlelanguagetranslator_portuguese_flag_choice', 'portuguese_flag', 'yes'),
(245, 'googlelanguagetranslator_floating_widget_text', 'Translate »', 'yes'),
(246, 'googlelanguagetranslator_floating_widget_text_allow_translation', '', 'yes'),
(247, 'widget_glt_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(248, 'glt_language_switcher_width', '100%', 'yes'),
(249, 'glt_language_switcher_text_color', '#32373c', 'yes'),
(250, 'glt_language_switcher_bg_color', '', 'yes'),
(251, 'glt_floating_widget_position', 'bottom_left', 'yes'),
(252, 'glt_floating_widget_text_color', '#ffffff', 'yes'),
(253, 'glt_floating_widget_bg_color', '#00d5d8', 'yes'),
(303, '_transient_is_multi_author', '0', 'yes'),
(304, '_transient_timeout_plugin_slugs', '1537175655', 'no'),
(305, '_transient_plugin_slugs', 'a:3:{i:0;s:19:"akismet/akismet.php";i:1;s:57:"google-language-translator/google-language-translator.php";i:2;s:9:"hello.php";}', 'no'),
(306, '_transient_timeout_dash_88ae138922fe95674369b1cb3d215a2b', '1537132455', 'no'),
(307, '_transient_dash_88ae138922fe95674369b1cb3d215a2b', '<div class="rss-widget"><p><strong>RSS Error:</strong> WP HTTP Error: cURL error 6: Could not resolve host: wordpress.org</p></div><div class="rss-widget"><p><strong>RSS Error:</strong> WP HTTP Error: cURL error 6: Could not resolve host: planet.wordpress.org</p></div><div class="rss-widget"><ul></ul></div>', 'no'),
(309, '_site_transient_timeout_theme_roots', '1537114761', 'no'),
(310, '_site_transient_theme_roots', 'a:4:{s:13:"twentyfifteen";s:7:"/themes";s:15:"twentyseventeen";s:7:"/themes";s:13:"twentysixteen";s:7:"/themes";s:6:"vivita";s:7:"/themes";}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=226 ;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(4, 5, '_wp_attached_file', '2018/07/espresso.jpg'),
(5, 5, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1200;s:4:"file";s:20:"2018/07/espresso.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"espresso-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"espresso-300x180.jpg";s:5:"width";i:300;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"espresso-768x461.jpg";s:5:"width";i:768;s:6:"height";i:461;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"espresso-1024x614.jpg";s:5:"width";i:1024;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:20:"espresso-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(6, 5, '_starter_content_theme', 'twentyseventeen'),
(8, 6, '_wp_attached_file', '2018/07/sandwich.jpg'),
(9, 6, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1200;s:4:"file";s:20:"2018/07/sandwich.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"sandwich-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"sandwich-300x180.jpg";s:5:"width";i:300;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"sandwich-768x461.jpg";s:5:"width";i:768;s:6:"height";i:461;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"sandwich-1024x614.jpg";s:5:"width";i:1024;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:20:"sandwich-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(10, 6, '_starter_content_theme', 'twentyseventeen'),
(12, 7, '_wp_attached_file', '2018/07/coffee.jpg'),
(13, 7, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1200;s:4:"file";s:18:"2018/07/coffee.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"coffee-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"coffee-300x180.jpg";s:5:"width";i:300;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"coffee-768x461.jpg";s:5:"width";i:768;s:6:"height";i:461;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"coffee-1024x614.jpg";s:5:"width";i:1024;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"coffee-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(14, 7, '_starter_content_theme', 'twentyseventeen'),
(17, 9, '_thumbnail_id', '55'),
(19, 10, '_thumbnail_id', '73'),
(21, 11, '_thumbnail_id', '70'),
(23, 12, '_thumbnail_id', '54'),
(25, 19, '_menu_item_type', 'custom'),
(26, 19, '_menu_item_menu_item_parent', '0'),
(27, 19, '_menu_item_object_id', '19'),
(28, 19, '_menu_item_object', 'custom'),
(29, 19, '_menu_item_target', ''),
(30, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(31, 19, '_menu_item_xfn', ''),
(32, 19, '_menu_item_url', 'http://localhost/wordpressprjfive/'),
(33, 20, '_menu_item_type', 'post_type'),
(34, 20, '_menu_item_menu_item_parent', '62'),
(35, 20, '_menu_item_object_id', '9'),
(36, 20, '_menu_item_object', 'page'),
(37, 20, '_menu_item_target', ''),
(38, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(39, 20, '_menu_item_xfn', ''),
(40, 20, '_menu_item_url', ''),
(41, 21, '_menu_item_type', 'post_type'),
(42, 21, '_menu_item_menu_item_parent', '0'),
(43, 21, '_menu_item_object_id', '11'),
(44, 21, '_menu_item_object', 'page'),
(45, 21, '_menu_item_target', ''),
(46, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(47, 21, '_menu_item_xfn', ''),
(48, 21, '_menu_item_url', ''),
(49, 22, '_menu_item_type', 'post_type'),
(50, 22, '_menu_item_menu_item_parent', '0'),
(51, 22, '_menu_item_object_id', '10'),
(52, 22, '_menu_item_object', 'page'),
(53, 22, '_menu_item_target', ''),
(54, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(55, 22, '_menu_item_xfn', ''),
(56, 22, '_menu_item_url', ''),
(57, 23, '_menu_item_type', 'custom'),
(58, 23, '_menu_item_menu_item_parent', '0'),
(59, 23, '_menu_item_object_id', '23'),
(60, 23, '_menu_item_object', 'custom'),
(61, 23, '_menu_item_target', ''),
(62, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(63, 23, '_menu_item_xfn', ''),
(64, 23, '_menu_item_url', 'https://www.yelp.com'),
(65, 24, '_menu_item_type', 'custom'),
(66, 24, '_menu_item_menu_item_parent', '0'),
(67, 24, '_menu_item_object_id', '24'),
(68, 24, '_menu_item_object', 'custom'),
(69, 24, '_menu_item_target', ''),
(70, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(71, 24, '_menu_item_xfn', ''),
(72, 24, '_menu_item_url', 'https://www.facebook.com/wordpress'),
(73, 25, '_menu_item_type', 'custom'),
(74, 25, '_menu_item_menu_item_parent', '0'),
(75, 25, '_menu_item_object_id', '25'),
(76, 25, '_menu_item_object', 'custom'),
(77, 25, '_menu_item_target', ''),
(78, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(79, 25, '_menu_item_xfn', ''),
(80, 25, '_menu_item_url', 'https://twitter.com/wordpress'),
(81, 26, '_menu_item_type', 'custom'),
(82, 26, '_menu_item_menu_item_parent', '0'),
(83, 26, '_menu_item_object_id', '26'),
(84, 26, '_menu_item_object', 'custom'),
(85, 26, '_menu_item_target', ''),
(86, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(87, 26, '_menu_item_xfn', ''),
(88, 26, '_menu_item_url', 'https://www.instagram.com/explore/tags/wordcamp/'),
(89, 27, '_menu_item_type', 'custom'),
(90, 27, '_menu_item_menu_item_parent', '0'),
(91, 27, '_menu_item_object_id', '27'),
(92, 27, '_menu_item_object', 'custom'),
(93, 27, '_menu_item_target', ''),
(94, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(95, 27, '_menu_item_xfn', ''),
(96, 27, '_menu_item_url', 'mailto:wordpress@example.com'),
(99, 28, '_wp_attached_file', '2018/07/myan8.jpg'),
(100, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:535;s:4:"file";s:17:"2018/07/myan8.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"myan8-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"myan8-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:17:"myan8-768x514.jpg";s:5:"width";i:768;s:6:"height";i:514;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:17:"myan8-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(101, 29, '_wp_attached_file', '2018/07/cropped-myan8.jpg'),
(102, 29, '_wp_attachment_context', 'site-icon'),
(103, 29, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:25:"2018/07/cropped-myan8.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"cropped-myan8-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"cropped-myan8-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:25:"cropped-myan8-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:13:"site_icon-270";a:4:{s:4:"file";s:25:"cropped-myan8-270x270.jpg";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}s:13:"site_icon-192";a:4:{s:4:"file";s:25:"cropped-myan8-192x192.jpg";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:10:"image/jpeg";}s:13:"site_icon-180";a:4:{s:4:"file";s:25:"cropped-myan8-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"site_icon-32";a:4:{s:4:"file";s:23:"cropped-myan8-32x32.jpg";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(108, 32, '_wp_attached_file', '2018/07/cropped-cropped-myan8.jpg'),
(109, 32, '_wp_attachment_context', 'custom-logo'),
(110, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:250;s:6:"height";i:250;s:4:"file";s:33:"2018/07/cropped-cropped-myan8.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"cropped-cropped-myan8-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:33:"cropped-cropped-myan8-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(117, 36, '_wp_attached_file', '2018/07/myan1.jpg'),
(118, 36, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:667;s:4:"file";s:17:"2018/07/myan1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"myan1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"myan1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:17:"myan1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:17:"myan1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(119, 37, '_wp_attached_file', '2018/07/cropped-myan1.jpg'),
(120, 37, '_wp_attachment_context', 'custom-header'),
(121, 37, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1334;s:4:"file";s:25:"2018/07/cropped-myan1.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"cropped-myan1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"cropped-myan1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"cropped-myan1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"cropped-myan1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:30:"twentyseventeen-featured-image";a:4:{s:4:"file";s:27:"cropped-myan1-2000x1200.jpg";s:5:"width";i:2000;s:6:"height";i:1200;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:25:"cropped-myan1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(122, 37, '_wp_attachment_custom_header_last_used_twentyseventeen', '1530699229'),
(123, 37, '_wp_attachment_is_custom_header', 'twentyseventeen'),
(126, 8, '_edit_lock', '1535855579:1'),
(127, 8, '_edit_last', '1'),
(129, 12, '_edit_lock', '1530905410:1'),
(130, 12, '_edit_last', '1'),
(131, 9, '_edit_lock', '1530873337:1'),
(132, 9, '_edit_last', '1'),
(137, 11, '_edit_lock', '1530874340:1'),
(138, 54, '_wp_attached_file', '2018/07/myan17.jpg'),
(139, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:670;s:4:"file";s:18:"2018/07/myan17.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"myan17-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"myan17-300x168.jpg";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"myan17-768x429.jpg";s:5:"width";i:768;s:6:"height";i:429;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"myan17-1024x572.jpg";s:5:"width";i:1024;s:6:"height";i:572;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"myan17-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(140, 55, '_wp_attached_file', '2018/07/myan16.jpg'),
(141, 55, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:18:"2018/07/myan16.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"myan16-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"myan16-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"myan16-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"myan16-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"myan16-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(142, 56, '_edit_last', '1'),
(143, 56, '_edit_lock', '1530873442:1'),
(144, 57, '_wp_attached_file', '2018/07/myan22.jpg'),
(145, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:608;s:4:"file";s:18:"2018/07/myan22.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"myan22-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"myan22-300x152.jpg";s:5:"width";i:300;s:6:"height";i:152;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"myan22-768x389.jpg";s:5:"width";i:768;s:6:"height";i:389;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"myan22-1024x519.jpg";s:5:"width";i:1024;s:6:"height";i:519;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"myan22-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(146, 56, '_thumbnail_id', '57'),
(149, 62, '_menu_item_type', 'post_type'),
(150, 62, '_menu_item_menu_item_parent', '0'),
(151, 62, '_menu_item_object_id', '61'),
(152, 62, '_menu_item_object', 'page'),
(153, 62, '_menu_item_target', ''),
(154, 62, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(155, 62, '_menu_item_xfn', ''),
(156, 62, '_menu_item_url', ''),
(157, 63, '_menu_item_type', 'post_type'),
(158, 63, '_menu_item_menu_item_parent', '62'),
(159, 63, '_menu_item_object_id', '56'),
(160, 63, '_menu_item_object', 'page'),
(161, 63, '_menu_item_target', ''),
(162, 63, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(163, 63, '_menu_item_xfn', ''),
(164, 63, '_menu_item_url', ''),
(165, 66, '_menu_item_type', 'post_type'),
(166, 66, '_menu_item_menu_item_parent', '62'),
(167, 66, '_menu_item_object_id', '59'),
(168, 66, '_menu_item_object', 'page'),
(169, 66, '_menu_item_target', ''),
(170, 66, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(171, 66, '_menu_item_xfn', ''),
(172, 66, '_menu_item_url', ''),
(175, 59, '_edit_lock', '1530874072:1'),
(176, 68, '_wp_attached_file', '2018/07/myan9.jpg'),
(177, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:17:"2018/07/myan9.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"myan9-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"myan9-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:17:"myan9-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:18:"myan9-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:17:"myan9-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(178, 59, '_edit_last', '1'),
(179, 59, '_thumbnail_id', '68'),
(180, 61, '_edit_lock', '1530874128:1'),
(181, 70, '_wp_attached_file', '2018/07/myan21.jpg'),
(182, 70, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:18:"2018/07/myan21.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"myan21-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"myan21-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"myan21-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"myan21-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"myan21-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(183, 11, '_edit_last', '1'),
(184, 1, '_edit_lock', '1530952390:1'),
(185, 1, '_edit_last', '1'),
(188, 10, '_edit_lock', '1530874566:1'),
(189, 73, '_wp_attached_file', '2018/07/myan20.jpg'),
(190, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:18:"2018/07/myan20.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"myan20-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"myan20-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"myan20-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"myan20-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"myan20-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(191, 10, '_edit_last', '1'),
(193, 79, '_menu_item_type', 'post_type'),
(194, 79, '_menu_item_menu_item_parent', '62'),
(195, 79, '_menu_item_object_id', '76'),
(196, 79, '_menu_item_object', 'page'),
(197, 79, '_menu_item_target', ''),
(198, 79, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(199, 79, '_menu_item_xfn', ''),
(200, 79, '_menu_item_url', ''),
(203, 76, '_edit_lock', '1530875578:1'),
(204, 83, '_wp_attached_file', '2018/07/myan10.jpg'),
(205, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1855;s:6:"height";i:1296;s:4:"file";s:18:"2018/07/myan10.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"myan10-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"myan10-300x210.jpg";s:5:"width";i:300;s:6:"height";i:210;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"myan10-768x537.jpg";s:5:"width";i:768;s:6:"height";i:537;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"myan10-1024x715.jpg";s:5:"width";i:1024;s:6:"height";i:715;s:9:"mime-type";s:10:"image/jpeg";}s:30:"twentyseventeen-featured-image";a:4:{s:4:"file";s:20:"myan10-1855x1200.jpg";s:5:"width";i:1855;s:6:"height";i:1200;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"myan10-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(206, 76, '_edit_last', '1'),
(207, 76, '_thumbnail_id', '83'),
(208, 85, '_edit_last', '1'),
(209, 85, '_edit_lock', '1530875612:1'),
(210, 86, '_wp_attached_file', '2018/07/myan4.jpg'),
(211, 86, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1280;s:6:"height";i:720;s:4:"file";s:17:"2018/07/myan4.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"myan4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"myan4-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:17:"myan4-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:18:"myan4-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:17:"myan4-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(212, 85, '_thumbnail_id', '86'),
(215, 96, '_wp_attached_file', '2018/07/myan15.jpg'),
(216, 96, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1199;s:6:"height";i:801;s:4:"file";s:18:"2018/07/myan15.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"myan15-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"myan15-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"myan15-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"myan15-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"myan15-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(217, 97, '_wp_attached_file', '2018/07/cropped-myan15.jpg'),
(218, 97, '_wp_attachment_context', 'custom-header'),
(219, 97, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1336;s:4:"file";s:26:"2018/07/cropped-myan15.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"cropped-myan15-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"cropped-myan15-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"cropped-myan15-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"cropped-myan15-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}s:30:"twentyseventeen-featured-image";a:4:{s:4:"file";s:28:"cropped-myan15-2000x1200.jpg";s:5:"width";i:2000;s:6:"height";i:1200;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:26:"cropped-myan15-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(220, 97, '_wp_attachment_custom_header_last_used_twentyseventeen', '1530945620'),
(221, 97, '_wp_attachment_is_custom_header', 'twentyseventeen'),
(222, 99, '_wp_trash_meta_status', 'publish'),
(223, 99, '_wp_trash_meta_time', '1535855921'),
(224, 101, '_wp_trash_meta_status', 'publish'),
(225, 101, '_wp_trash_meta_time', '1535856059');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=104 ;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-07-01 01:04:39', '2018-07-01 01:04:39', '<strong><em>An important part of Myanmar life is food.Both Myanmar men and women take a lively interest in cooking.The basic item of a Burmese meal is usually rice, taken with what westerners would describe as a "curry".</em></strong>', '', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2018-07-06 10:56:03', '2018-07-06 10:56:03', '', 0, 'http://localhost/wordpressprjfive/?p=1', 0, 'post', '', 1),
(2, 1, '2018-07-01 01:04:39', '2018-07-01 01:04:39', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/wordpressprjfive/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2018-07-01 01:04:39', '2018-07-01 01:04:39', '', 0, 'http://localhost/wordpressprjfive/?page_id=2', 0, 'page', '', 0),
(5, 1, '2018-07-04 08:26:20', '2018-07-04 08:26:20', '', 'Espresso', '', 'inherit', 'open', 'closed', '', 'espresso', '', '', '2018-07-04 08:26:20', '2018-07-04 08:26:20', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/espresso.jpg', 0, 'attachment', 'image/jpeg', 0),
(6, 1, '2018-07-04 08:26:20', '2018-07-04 08:26:20', '', 'Sandwich', '', 'inherit', 'open', 'closed', '', 'sandwich', '', '', '2018-07-04 08:26:20', '2018-07-04 08:26:20', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/sandwich.jpg', 0, 'attachment', 'image/jpeg', 0),
(7, 1, '2018-07-04 08:26:20', '2018-07-04 08:26:20', '', 'Coffee', '', 'inherit', 'open', 'closed', '', 'coffee', '', '', '2018-07-04 08:26:20', '2018-07-04 08:26:20', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/coffee.jpg', 0, 'attachment', 'image/jpeg', 0),
(8, 1, '2018-07-04 08:26:20', '2018-07-04 08:26:20', '<strong>Bagan<em> is one of the ancient city in Myanmar.Bangan is full of  traditonal culture of Myanmar and People of Bagan are kind, sweet and helpful........</em></strong>', 'Bagan', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-09-02 02:35:16', '2018-09-02 02:35:16', '', 0, 'http://localhost/wordpressprjfive/?page_id=8', 0, 'page', '', 0),
(9, 1, '2018-07-04 08:26:20', '2018-07-04 08:26:20', '<em><strong>It is situated in the southern coastline of Myanmar.It is perfect for scuba diving, snorkeling and island hopping.Nature and culture-based tourism is developed in Myanmar.</strong></em>', 'Myeik Archipelago', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-07-06 10:37:55', '2018-07-06 10:37:55', '', 0, 'http://localhost/wordpressprjfive/?page_id=9', 0, 'page', '', 0),
(10, 1, '2018-07-04 08:26:21', '2018-07-04 08:26:21', 'This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.', 'Contact to Famous Hotel', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-07-06 10:58:25', '2018-07-06 10:58:25', '', 0, 'http://localhost/wordpressprjfive/?page_id=10', 0, 'page', '', 0),
(11, 1, '2018-07-04 08:26:21', '2018-07-04 08:26:21', '', 'Traditional food', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2018-07-06 10:54:40', '2018-07-06 10:54:40', '', 0, 'http://localhost/wordpressprjfive/?page_id=11', 0, 'page', '', 0),
(12, 1, '2018-07-04 08:26:21', '2018-07-04 08:26:21', '<em><strong>In the Shan State Inlay Lake Region is an area with strange life style. This lake is also a great tourist attraction.And the Inntha Boatmen is that they row their boats by standing up with one Leg hooked around the oar to pull it Pindaya cave is also famous.</strong></em>', 'Shan State (Inlay Lake)', '', 'publish', 'closed', 'closed', '', 'a-homepage-section', '', '', '2018-07-06 10:36:47', '2018-07-06 10:36:47', '', 0, 'http://localhost/wordpressprjfive/?page_id=12', 0, 'page', '', 0),
(14, 1, '2018-07-04 08:26:20', '2018-07-04 08:26:20', 'Welcome to your site! This is your homepage, which is what most visitors will see when they come to your site for the first time.', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-07-04 08:26:20', '2018-07-04 08:26:20', '', 8, 'http://localhost/wordpressprjfive/index.php/2018/07/04/8-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2018-07-04 08:26:20', '2018-07-04 08:26:20', 'You might be an artist who would like to introduce yourself and your work here or maybe you&rsquo;re a business with a mission to describe.', 'About', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2018-07-04 08:26:20', '2018-07-04 08:26:20', '', 9, 'http://localhost/wordpressprjfive/index.php/2018/07/04/9-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-07-04 08:26:21', '2018-07-04 08:26:21', 'This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.', 'Contact', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-07-04 08:26:21', '2018-07-04 08:26:21', '', 10, 'http://localhost/wordpressprjfive/index.php/2018/07/04/10-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2018-07-04 08:26:21', '2018-07-04 08:26:21', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2018-07-04 08:26:21', '2018-07-04 08:26:21', '', 11, 'http://localhost/wordpressprjfive/index.php/2018/07/04/11-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2018-07-04 08:26:21', '2018-07-04 08:26:21', 'This is an example of a homepage section. Homepage sections can be any page other than the homepage itself, including the page that shows your latest blog posts.', 'A homepage section', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-07-04 08:26:21', '2018-07-04 08:26:21', '', 12, 'http://localhost/wordpressprjfive/index.php/2018/07/04/12-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2018-07-04 08:26:22', '2018-07-04 08:26:22', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-07-04 08:26:22', '2018-07-04 08:26:22', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/04/home/', 0, 'nav_menu_item', '', 0),
(20, 1, '2018-07-04 08:26:22', '2018-07-04 08:26:22', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2018-07-06 10:44:47', '2018-07-06 10:44:47', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/04/20/', 5, 'nav_menu_item', '', 0),
(21, 1, '2018-07-04 08:26:23', '2018-07-04 08:26:23', ' ', '', '', 'publish', 'closed', 'closed', '', '21', '', '', '2018-07-06 10:09:06', '2018-07-06 10:09:06', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/04/21/', 2, 'nav_menu_item', '', 0),
(22, 1, '2018-07-04 08:26:24', '2018-07-04 08:26:24', ' ', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2018-07-06 10:09:06', '2018-07-06 10:09:06', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/04/22/', 3, 'nav_menu_item', '', 0),
(23, 1, '2018-07-04 08:26:24', '2018-07-04 08:26:24', '', 'Yelp', '', 'publish', 'closed', 'closed', '', 'yelp', '', '', '2018-07-04 08:26:24', '2018-07-04 08:26:24', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/04/yelp/', 0, 'nav_menu_item', '', 0),
(24, 1, '2018-07-04 08:26:25', '2018-07-04 08:26:25', '', 'Facebook', '', 'publish', 'closed', 'closed', '', 'facebook', '', '', '2018-07-04 08:26:25', '2018-07-04 08:26:25', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/04/facebook/', 1, 'nav_menu_item', '', 0),
(25, 1, '2018-07-04 08:26:26', '2018-07-04 08:26:26', '', 'Twitter', '', 'publish', 'closed', 'closed', '', 'twitter', '', '', '2018-07-04 08:26:26', '2018-07-04 08:26:26', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/04/twitter/', 2, 'nav_menu_item', '', 0),
(26, 1, '2018-07-04 08:26:26', '2018-07-04 08:26:26', '', 'Instagram', '', 'publish', 'closed', 'closed', '', 'instagram', '', '', '2018-07-04 08:26:26', '2018-07-04 08:26:26', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/04/instagram/', 3, 'nav_menu_item', '', 0),
(27, 1, '2018-07-04 08:26:27', '2018-07-04 08:26:27', '', 'Email', '', 'publish', 'closed', 'closed', '', 'email', '', '', '2018-07-04 08:26:27', '2018-07-04 08:26:27', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/04/email/', 4, 'nav_menu_item', '', 0),
(28, 1, '2018-07-04 08:27:55', '2018-07-04 08:27:55', '', 'myan8', '', 'inherit', 'open', 'closed', '', 'myan8', '', '', '2018-07-04 08:27:55', '2018-07-04 08:27:55', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan8.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 1, '2018-07-04 08:28:08', '2018-07-04 08:28:08', 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/cropped-myan8.jpg', 'cropped-myan8.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-myan8-jpg', '', '', '2018-07-04 08:28:08', '2018-07-04 08:28:08', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/cropped-myan8.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2018-07-04 08:29:41', '2018-07-04 08:29:41', 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/cropped-cropped-myan8.jpg', 'cropped-cropped-myan8.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-cropped-myan8-jpg', '', '', '2018-07-04 08:29:41', '2018-07-04 08:29:41', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/cropped-cropped-myan8.jpg', 0, 'attachment', 'image/jpeg', 0),
(36, 1, '2018-07-04 08:33:55', '2018-07-04 08:33:55', '', 'myan1', '', 'inherit', 'open', 'closed', '', 'myan1', '', '', '2018-07-04 08:33:55', '2018-07-04 08:33:55', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan1.jpg', 0, 'attachment', 'image/jpeg', 0),
(37, 1, '2018-07-04 08:34:05', '2018-07-04 08:34:05', '', 'cropped-myan1.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-myan1-jpg', '', '', '2018-07-04 08:34:05', '2018-07-04 08:34:05', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/cropped-myan1.jpg', 0, 'attachment', 'image/jpeg', 0),
(40, 1, '2018-07-04 10:37:06', '2018-07-04 10:37:06', '<strong><em>Bagan is one of the ancient city in Myanmar.Bangan is full of  traditonal culture of Myanmar and People of Bagan are kind, sweet and helpful........</em></strong>', 'Bagan', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-07-04 10:37:06', '2018-07-04 10:37:06', '', 8, 'http://localhost/wordpressprjfive/index.php/2018/07/04/8-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-07-04 10:37:20', '2018-07-04 10:37:20', '<em>Bagan</em><strong><em> is one of the ancient city in Myanmar.Bangan is full of  traditonal culture of Myanmar and People of Bagan are kind, sweet and helpful........</em></strong>', 'Bagan', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-07-04 10:37:20', '2018-07-04 10:37:20', '', 8, 'http://localhost/wordpressprjfive/index.php/2018/07/04/8-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2018-07-06 09:59:08', '2018-07-06 09:59:08', 'In the Shan State Inlay Lake Region is an aera with ka strange lige style. This lake is also a great tourist attraction.And the Inntha Boatmen is that they row their boats by standing up with one Leg hooked around the oar to pull it.&lt;br&gt;&lt;br&gt;Pindaya cave is also famous.', 'Shan State (Inlay Lake)', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-07-06 09:59:08', '2018-07-06 09:59:08', '', 12, 'http://localhost/wordpressprjfive/index.php/2018/07/06/12-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2018-07-06 10:00:11', '2018-07-06 10:00:11', 'In the Shan State Inlay Lake Region is an aera with ka strange lige style. This lake is also a great tourist attraction.And the Inntha Boatmen is that they row their boats by standing up with one Leg hooked around the oar to pull it Pindaya cave is also famous.', 'Shan State (Inlay Lake)', '', 'inherit', 'closed', 'closed', '', '12-autosave-v1', '', '', '2018-07-06 10:00:11', '2018-07-06 10:00:11', '', 12, 'http://localhost/wordpressprjfive/index.php/2018/07/06/12-autosave-v1/', 0, 'revision', '', 0),
(48, 1, '2018-07-06 10:00:38', '2018-07-06 10:00:38', '<em><strong>In the Shan State Inlay Lake Region is an area with strange life style. This lake is also a great tourist attraction.And the Inntha Boatmen is that they row their boats by standing up with one Leg hooked around the oar to pull it Pindaya cave is also famous.</strong></em>', 'Shan State (Inlay Lake)', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-07-06 10:00:38', '2018-07-06 10:00:38', '', 12, 'http://localhost/wordpressprjfive/index.php/2018/07/06/12-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2018-07-06 10:05:33', '2018-07-06 10:05:33', 'You might be an artist who would like to introduce yourself and your work here or maybe you’re a business with a mission to describe.', 'My', '', 'inherit', 'closed', 'closed', '', '9-autosave-v1', '', '', '2018-07-06 10:05:33', '2018-07-06 10:05:33', '', 9, 'http://localhost/wordpressprjfive/index.php/2018/07/06/9-autosave-v1/', 0, 'revision', '', 0),
(50, 1, '2018-07-06 10:06:23', '2018-07-06 10:06:23', '<em><strong>It is situated in the southern coastline of Myanmar.It is perfect for scuba diving, snorkeling and island hopping.Nature and culture-based tourism is developed in Myanmar.</strong></em>', 'Myeik Archipelago', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2018-07-06 10:06:23', '2018-07-06 10:06:23', '', 9, 'http://localhost/wordpressprjfive/index.php/2018/07/06/9-revision-v1/', 0, 'revision', '', 0),
(53, 1, '2018-07-06 10:52:27', '2018-07-06 10:52:27', '', 'Traditional food', '', 'inherit', 'closed', 'closed', '', '11-autosave-v1', '', '', '2018-07-06 10:52:27', '2018-07-06 10:52:27', '', 11, 'http://localhost/wordpressprjfive/index.php/2018/07/06/11-autosave-v1/', 0, 'revision', '', 0),
(54, 1, '2018-07-06 10:36:38', '2018-07-06 10:36:38', '', 'myan17', '', 'inherit', 'open', 'closed', '', 'myan17', '', '', '2018-07-06 10:36:38', '2018-07-06 10:36:38', '', 12, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan17.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2018-07-06 10:37:43', '2018-07-06 10:37:43', '', 'myan16', '', 'inherit', 'open', 'closed', '', 'myan16', '', '', '2018-07-06 10:37:43', '2018-07-06 10:37:43', '', 9, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan16.jpg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2018-07-06 10:39:41', '2018-07-06 10:39:41', '<em><strong>Situated in the ancient city of Amarapura, Mandalay Region.It is one of Myanmar''s top tourist''s attractions.It is the longest and oldest teak wood bridge in the world.It stretches out for 1.2 kilometers which is a pretty impressive feet seeing as it was built over 150 years ago</strong></em>', 'U Bein Bridge', '', 'publish', 'closed', 'closed', '', 'u-bein-bridge', '', '', '2018-07-06 10:39:41', '2018-07-06 10:39:41', '', 0, 'http://localhost/wordpressprjfive/?page_id=56', 0, 'page', '', 0),
(57, 1, '2018-07-06 10:39:34', '2018-07-06 10:39:34', '', 'myan22', '', 'inherit', 'open', 'closed', '', 'myan22', '', '', '2018-07-06 10:39:34', '2018-07-06 10:39:34', '', 56, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan22.jpg', 0, 'attachment', 'image/jpeg', 0),
(58, 1, '2018-07-06 10:39:41', '2018-07-06 10:39:41', '<em><strong>Situated in the ancient city of Amarapura, Mandalay Region.It is one of Myanmar''s top tourist''s attractions.It is the longest and oldest teak wood bridge in the world.It stretches out for 1.2 kilometers which is a pretty impressive feet seeing as it was built over 150 years ago</strong></em>', 'U Bein Bridge', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2018-07-06 10:39:41', '2018-07-06 10:39:41', '', 56, 'http://localhost/wordpressprjfive/index.php/2018/07/06/56-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2018-07-06 10:44:46', '2018-07-06 10:44:46', '<em><strong>ShweDagon Pagoda is one of the famous and wonderful pagoda in Myanmar..It is also one of the histotical pagoda in Myanmar...</strong></em>', 'ShweDagon Pagoda', '', 'publish', 'closed', 'closed', '', 'something', '', '', '2018-07-06 10:50:06', '2018-07-06 10:50:06', '', 0, 'http://localhost/wordpressprjfive/?page_id=59', 0, 'page', '', 0),
(61, 1, '2018-07-06 10:44:46', '2018-07-06 10:44:46', '', 'Attractive places', '', 'publish', 'closed', 'closed', '', 'attractive-places', '', '', '2018-07-06 10:44:46', '2018-07-06 10:44:46', '', 0, 'http://localhost/wordpressprjfive/?page_id=61', 0, 'page', '', 0),
(62, 1, '2018-07-06 10:44:45', '2018-07-06 10:44:45', ' ', '', '', 'publish', 'closed', 'closed', '', '62', '', '', '2018-07-06 10:44:45', '2018-07-06 10:44:45', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/06/62/', 4, 'nav_menu_item', '', 0),
(63, 1, '2018-07-06 10:44:46', '2018-07-06 10:44:46', ' ', '', '', 'publish', 'closed', 'closed', '', '63', '', '', '2018-07-06 10:44:46', '2018-07-06 10:44:46', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/06/63/', 6, 'nav_menu_item', '', 0),
(64, 1, '2018-07-06 10:44:46', '2018-07-06 10:44:46', '', 'something', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2018-07-06 10:44:46', '2018-07-06 10:44:46', '', 59, 'http://localhost/wordpressprjfive/index.php/2018/07/06/59-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2018-07-06 10:44:46', '2018-07-06 10:44:46', '', 'Attractive places', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2018-07-06 10:44:46', '2018-07-06 10:44:46', '', 61, 'http://localhost/wordpressprjfive/index.php/2018/07/06/61-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2018-07-06 10:44:47', '2018-07-06 10:44:47', ' ', '', '', 'publish', 'closed', 'closed', '', '66', '', '', '2018-07-06 10:44:47', '2018-07-06 10:44:47', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/06/66/', 7, 'nav_menu_item', '', 0),
(67, 1, '2018-07-06 10:48:56', '2018-07-06 10:48:56', 'ShweDagon Pagoda is one of the famous and wonderful pagoda in Myanmar..It is one of the histotical Pa', 'ShweDagon Pagoda', '', 'inherit', 'closed', 'closed', '', '59-autosave-v1', '', '', '2018-07-06 10:48:56', '2018-07-06 10:48:56', '', 59, 'http://localhost/wordpressprjfive/index.php/2018/07/06/59-autosave-v1/', 0, 'revision', '', 0),
(68, 1, '2018-07-06 10:49:56', '2018-07-06 10:49:56', '', 'myan9', '', 'inherit', 'open', 'closed', '', 'myan9', '', '', '2018-07-06 10:49:56', '2018-07-06 10:49:56', '', 59, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan9.jpg', 0, 'attachment', 'image/jpeg', 0),
(69, 1, '2018-07-06 10:50:06', '2018-07-06 10:50:06', '<em><strong>ShweDagon Pagoda is one of the famous and wonderful pagoda in Myanmar..It is also one of the histotical pagoda in Myanmar...</strong></em>', 'ShweDagon Pagoda', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2018-07-06 10:50:06', '2018-07-06 10:50:06', '', 59, 'http://localhost/wordpressprjfive/index.php/2018/07/06/59-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-07-06 10:53:18', '2018-07-06 10:53:18', '', 'myan21', '', 'inherit', 'open', 'closed', '', 'myan21', '', '', '2018-07-06 10:53:18', '2018-07-06 10:53:18', '', 11, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan21.jpg', 0, 'attachment', 'image/jpeg', 0),
(71, 1, '2018-07-06 10:53:26', '2018-07-06 10:53:26', '', 'Traditional food', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2018-07-06 10:53:26', '2018-07-06 10:53:26', '', 11, 'http://localhost/wordpressprjfive/index.php/2018/07/06/11-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2018-07-06 10:55:50', '2018-07-06 10:55:50', '<strong><em>An important part of Myanmar life is food.Both Myanmar men and women take a lively interest in cooking.The basic item of a Burmese meal is usually rice, taken with what westerners would describe as a "curry".</em></strong>', '', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-07-06 10:55:50', '2018-07-06 10:55:50', '', 1, 'http://localhost/wordpressprjfive/index.php/2018/07/06/1-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2018-07-06 10:57:35', '2018-07-06 10:57:35', '', 'myan20', '', 'inherit', 'open', 'closed', '', 'myan20', '', '', '2018-07-06 10:57:35', '2018-07-06 10:57:35', '', 10, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan20.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2018-07-06 10:58:12', '2018-07-06 10:58:12', 'This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.', 'Contact to Famous Hotel', '', 'inherit', 'closed', 'closed', '', '10-autosave-v1', '', '', '2018-07-06 10:58:12', '2018-07-06 10:58:12', '', 10, 'http://localhost/wordpressprjfive/index.php/2018/07/06/10-autosave-v1/', 0, 'revision', '', 0),
(75, 1, '2018-07-06 10:58:18', '2018-07-06 10:58:18', 'This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.', 'Contact to Famous Hotel', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-07-06 10:58:18', '2018-07-06 10:58:18', '', 10, 'http://localhost/wordpressprjfive/index.php/2018/07/06/10-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2018-07-06 10:59:51', '2018-07-06 10:59:51', '<h1 class="threee">Kyaik Htee Yoe Pagoda visited by people all people from all over the country and tourists.KyaikHtiYoe pagoda is one of the famous and wonderful pagoda in Myanmar..</h1>', 'Kyaik Htee Yoe Pagoda', '', 'publish', 'closed', 'closed', '', 'kyaik-htee-yoe-pagoda', '', '', '2018-07-06 11:08:37', '2018-07-06 11:08:37', '', 0, 'http://localhost/wordpressprjfive/?page_id=76', 0, 'page', '', 0),
(78, 1, '2018-07-06 10:59:51', '2018-07-06 10:59:51', '', 'Kyaik Htee Yoe Pagoda', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2018-07-06 10:59:51', '2018-07-06 10:59:51', '', 76, 'http://localhost/wordpressprjfive/index.php/2018/07/06/76-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2018-07-06 10:59:51', '2018-07-06 10:59:51', ' ', '', '', 'publish', 'closed', 'closed', '', '79', '', '', '2018-07-06 10:59:51', '2018-07-06 10:59:51', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/06/79/', 8, 'nav_menu_item', '', 0),
(82, 1, '2018-07-06 11:07:03', '2018-07-06 11:07:03', '<h1 class="threee">Kyaik Htee Yoe Pagoda visited by people all people from all over the country and tourists.</h1>', 'Kyaik Htee Yoe Pagoda', '', 'inherit', 'closed', 'closed', '', '76-autosave-v1', '', '', '2018-07-06 11:07:03', '2018-07-06 11:07:03', '', 76, 'http://localhost/wordpressprjfive/index.php/2018/07/06/76-autosave-v1/', 0, 'revision', '', 0),
(83, 1, '2018-07-06 11:08:29', '2018-07-06 11:08:29', '', 'myan10', '', 'inherit', 'open', 'closed', '', 'myan10', '', '', '2018-07-06 11:08:29', '2018-07-06 11:08:29', '', 76, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan10.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 1, '2018-07-06 11:08:37', '2018-07-06 11:08:37', '<h1 class="threee">Kyaik Htee Yoe Pagoda visited by people all people from all over the country and tourists.KyaikHtiYoe pagoda is one of the famous and wonderful pagoda in Myanmar..</h1>', 'Kyaik Htee Yoe Pagoda', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2018-07-06 11:08:37', '2018-07-06 11:08:37', '', 76, 'http://localhost/wordpressprjfive/index.php/2018/07/06/76-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2018-07-06 11:12:59', '2018-07-06 11:12:59', '<em><strong>Chaung Beach is very pleasant..The water is clear and blue..Seafoods are always fresh and you can also eat and drink coconut that is very fresh..ChaungTha Twilight is amazing pleasant..</strong></em>', 'ChaungTha Beach', '', 'publish', 'closed', 'closed', '', 'chaungtha-beach', '', '', '2018-07-06 11:12:59', '2018-07-06 11:12:59', '', 0, 'http://localhost/wordpressprjfive/?page_id=85', 0, 'page', '', 0),
(86, 1, '2018-07-06 11:12:52', '2018-07-06 11:12:52', '', 'myan4', '', 'inherit', 'open', 'closed', '', 'myan4', '', '', '2018-07-06 11:12:52', '2018-07-06 11:12:52', '', 85, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan4.jpg', 0, 'attachment', 'image/jpeg', 0),
(87, 1, '2018-07-06 11:12:59', '2018-07-06 11:12:59', '<em><strong>Chaung Beach is very pleasant..The water is clear and blue..Seafoods are always fresh and you can also eat and drink coconut that is very fresh..ChaungTha Twilight is amazing pleasant..</strong></em>', 'ChaungTha Beach', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2018-07-06 11:12:59', '2018-07-06 11:12:59', '', 85, 'http://localhost/wordpressprjfive/index.php/2018/07/06/85-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2018-07-06 20:37:26', '2018-07-06 20:37:26', '/*\nYou can add your own CSS here.\n\nClick the help icon above to learn more.\n*/\n\n.site-description {\n    color: white !important;\n    font-size: 29px !important;\n    font-weight: bold !important;\n}\n.site-title a{\n	text-shadow: 2px 2px 5px black;\n}\n.site-title p{\n	text-shadow: 3px 3px 1px black !important;\n}', 'twentyseventeen', '', 'publish', 'closed', 'closed', '', 'twentyseventeen', '', '', '2018-09-02 02:40:58', '2018-09-02 02:40:58', '', 0, 'http://localhost/wordpressprjfive/index.php/2018/07/06/twentyseventeen/', 0, 'custom_css', '', 0),
(94, 1, '2018-07-06 20:37:26', '2018-07-06 20:37:26', '/*\nYou can add your own CSS here.\n\nClick the help icon above to learn more.\n*/\n\n.site-description {\n    color: white !important;\n    font-size: 29px !important;\n    font-weight: bold !important;\n}', 'twentyseventeen', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2018-07-06 20:37:26', '2018-07-06 20:37:26', '', 93, 'http://localhost/wordpressprjfive/index.php/2018/07/06/93-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2018-07-06 22:46:16', '2018-07-06 22:46:16', '<strong>Bagan<em> is one of the ancient city in Myanmar.Bangan is full of  traditonal culture of Myanmar and People of Bagan are kind, sweet and helpful........</em></strong>', 'Bagan', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-07-06 22:46:16', '2018-07-06 22:46:16', '', 8, 'http://localhost/wordpressprjfive/index.php/2018/07/06/8-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2018-07-07 06:37:51', '2018-07-07 06:37:51', '', 'myan15', '', 'inherit', 'open', 'closed', '', 'myan15', '', '', '2018-07-07 06:37:51', '2018-07-07 06:37:51', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/myan15.jpg', 0, 'attachment', 'image/jpeg', 0),
(97, 1, '2018-07-07 06:38:04', '2018-07-07 06:38:04', '', 'cropped-myan15.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-myan15-jpg', '', '', '2018-07-07 06:38:04', '2018-07-07 06:38:04', '', 0, 'http://localhost/wordpressprjfive/wp-content/uploads/2018/07/cropped-myan15.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 1, '2018-09-02 02:38:41', '2018-09-02 02:38:41', '{\n    "custom_css[twentyseventeen]": {\n        "value": "/*\\nYou can add your own CSS here.\\n\\nClick the help icon above to learn more.\\n*/\\n\\n.site-description {\\n    color: white !important;\\n    font-size: 29px !important;\\n    font-weight: bold !important;\\n}\\n.site-title a{\\n\\ttext-shadow: 2px 2px 5px black;\\n}",\n        "type": "custom_css",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8bb38f88-eedd-40fd-9283-21f1471d502d', '', '', '2018-09-02 02:38:41', '2018-09-02 02:38:41', '', 0, 'http://localhost/wordpressprjfive/?p=99', 0, 'customize_changeset', '', 0),
(100, 1, '2018-09-02 02:38:41', '2018-09-02 02:38:41', '/*\nYou can add your own CSS here.\n\nClick the help icon above to learn more.\n*/\n\n.site-description {\n    color: white !important;\n    font-size: 29px !important;\n    font-weight: bold !important;\n}\n.site-title a{\n	text-shadow: 2px 2px 5px black;\n}', 'twentyseventeen', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2018-09-02 02:38:41', '2018-09-02 02:38:41', '', 93, 'http://localhost/wordpressprjfive/index.php/2018/09/02/93-revision-v1/', 0, 'revision', '', 0),
(101, 1, '2018-09-02 02:40:58', '2018-09-02 02:40:58', '{\n    "custom_css[twentyseventeen]": {\n        "value": "/*\\nYou can add your own CSS here.\\n\\nClick the help icon above to learn more.\\n*/\\n\\n.site-description {\\n    color: white !important;\\n    font-size: 29px !important;\\n    font-weight: bold !important;\\n}\\n.site-title a{\\n\\ttext-shadow: 2px 2px 5px black;\\n}\\n.site-title p{\\n\\ttext-shadow: 3px 3px 1px black !important;\\n}",\n        "type": "custom_css",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '7d28bdac-af95-4eb9-8510-4b333baed406', '', '', '2018-09-02 02:40:58', '2018-09-02 02:40:58', '', 0, 'http://localhost/wordpressprjfive/?p=101', 0, 'customize_changeset', '', 0),
(102, 1, '2018-09-02 02:40:58', '2018-09-02 02:40:58', '/*\nYou can add your own CSS here.\n\nClick the help icon above to learn more.\n*/\n\n.site-description {\n    color: white !important;\n    font-size: 29px !important;\n    font-weight: bold !important;\n}\n.site-title a{\n	text-shadow: 2px 2px 5px black;\n}\n.site-title p{\n	text-shadow: 3px 3px 1px black !important;\n}', 'twentyseventeen', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2018-09-02 02:40:58', '2018-09-02 02:40:58', '', 93, 'http://localhost/wordpressprjfive/index.php/2018/09/02/93-revision-v1/', 0, 'revision', '', 0),
(103, 1, '2018-09-16 09:14:12', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-09-16 09:14:12', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpressprjfive/?p=103', 0, 'post', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Top Menu', 'top-menu', 0),
(3, 'Social Links Menu', 'social-links-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(19, 2, 0),
(20, 2, 0),
(21, 2, 0),
(22, 2, 0),
(23, 3, 0),
(24, 3, 0),
(25, 3, 0),
(26, 3, 0),
(27, 3, 0),
(62, 2, 0),
(63, 2, 0),
(66, 2, 0),
(79, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 8),
(3, 3, 'nav_menu', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Hnin Oo Wai'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:1:{s:64:"e8d847feb7ad53b6b140d06b7363c5220c6f98db833bb9af0f4e8ea190f96adb";a:4:{s:10:"expiration";i:1537262049;s:2:"ip";s:3:"::1";s:2:"ua";s:73:"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:36.0) Gecko/20100101 Firefox/36.0";s:5:"login";i:1537089249;}}'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '103'),
(17, 1, 'wp_user-settings', 'libraryContent=upload'),
(18, 1, 'wp_user-settings-time', '1535855712'),
(19, 1, 'closedpostboxes_page', 'a:0:{}'),
(20, 1, 'metaboxhidden_page', 'a:6:{i:0;s:12:"revisionsdiv";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:11:"commentsdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Hnin Oo Wai', '$P$B5WpIHl7Ml0E2tQPxEV5RL2K.l7YPj0', 'hnin-oo-wai', 'hninminseok@gmail.com', '', '2018-07-01 01:04:38', '', 0, 'Hnin Oo Wai');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
