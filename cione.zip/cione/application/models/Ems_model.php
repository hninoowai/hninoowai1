<?php 
/**
* 
*/
class Ems_model extends CI_Model
{
	
	public function __Construct()
	{
		# code...
		parent::__Construct();

	}
	public function addstudent($studentArray)
	{
		$this->db->insert('cionestud',$studentArray);
	}

	public function update($student_array, $id)
	{
		$this->db->set($student_array); 
		$this->db->where("id",$id);
		$this->db->update("cionestud",$student_array);

	}
	public function delete_student($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('cionestud');
	}
	

	public function addadmin($studentaarray)
	{
		$this->db->insert('registeration',$studentaarray);
	}

	 /*public function login_valid($username, $password) {

        $password = md5($password);
        $q = $this->db->where(['admin_name' => $username, 'admin_password' => $password])
                ->get('admin');
        if ($q->num_rows) {
                
            return $q->row()->id;
            //return TRUE;
        } else {
            return FALSE;
        }
    }
*/
    /*login start*/
    function login($admin_name, $admin_password) {

    	$query = $this ->db->query("SELECT * FROM admin")-> result_array();
    	if(!query){
    		die('Error:' .mysql_error());
    	}
    	else{
       		//code

    		foreach ($query as $row) {
       			# code...
    			if ($row['admin_name']==$admin_name) {
       				# code...
    				if ($row['admin_password']==$admin_password) {
       					# code...
    					$result=true;
    					break;
    				}else{
    					$result=false;
    				}
    			} else {
    				$result=false;
    			}
    		}

    		if ($result=true) {
       			# code...
    			return true;
    		} else{
    			return false;
    		}


       	} //end else
    } // end function
   

    

   
}


?>