<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ems extends CI_Controller {

	public function index()
	{
		$studentlist=$this->db->get('cionestud');
		$data['studentlist']=$studentlist->result();
		$this->load->view('studentlist',$data);
	}
	 public function loginview(){
        $this->load->view('admin_login');
    }
     public function logoutview(){
        $this->load->view('registeration');
    }



	public function addstudent()
	{
		# code...
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$phone=$this->input->post('phone');
		$password=$this->input->post('password');
		$studentArray = array(
			'name'=>$name,
			'email'=>$email,
			'phone'=>$phone,
			'password'=>$password

		);

		$this->Ems_model->addstudent($studentArray);

		$this->session->set_flashdata('success', '<div class="alert alert-success">
			<a href="#" class="close" data-dismiss="alert" aria-lable="close">&times;</a>
			<strong>
			Well done!
			</strong>
			New Expense is Added.!!
			</div>');


		redirect(base_url('Ems'));

	}



	public function updatestudent()
	{
		# code...
		$id=$this->input->post('id');
		$name= $this->input->post('name');
		$email= $this->input->post('email');
		$phone= $this->input->post('phone');
		$password= $this->input->post('password');
		$student_array = array(
			'name'=>$name,
			'email'=>$email,
			'phone'=>$phone,
			'password'=>$password
		);

		$this->Ems_model->update($student_array, $id);
		$studentlist=$this->db->get('cionestud');
		$data['studentlist']=$studentlist->result();
		$this->load->view('studentlist',$data);
		$this->session->set_flashdata('update', '<div class="alert alert-success">
			<a href="#" class="close" data-dismiss="alert" aris-label="close">&times;</a>
			<strong>
			Well done!
			</strong>
			update successful.!!!!!
			</div>');
		
	

	}
	public function delete(){
		$id=$this->uri->segment(3);
		$this->Ems_model->delete_student($id);
		$studentlist=$this->db->get('cionestud');
		$data['studentlist']=$studentlist->result();
		$this->load->view('studentlist',$data);
		$this->session->set_flashdata('delete', '<div class="alert alert-success">
			<a href="#" class="close" data-dismiss="alert" aris-label="close">&times;</a>
			<strong>
			Well done!
			</strong>
			Expense is Delete!!!
			</div>');
	}
	


	public function login()
	{
		
		$data['errmsg'] ='';
		$this->load->view('admin_login', $data);

	}


	public function loginState()
	{
		# code...
		$admin_name= $this->input->post('admin_name');
		$admin_password= $this->input->post('admin_password');

		$login = $this->Ems_model->login($admin_name, $admin_password);

		if ($login==true) {
		 	# code...
			redirect(base_url('Ems/backend'));
		} 
		else{
			$data['errmsg']="Username and Password does not match!";
			$this->load->view('admin_login',$data);
		}
	}

	public function backend()
	{
		# code...
		$studentlist=$this->db->get('cionestud');
		$data['studentlist']=$studentlist->result();
		$this->load->view('studentlist',$data);
	}
	/*public function logout(){
		$this->session->sess_destory();
		redirect(base_url('ems/logout'));
	}*/


}
