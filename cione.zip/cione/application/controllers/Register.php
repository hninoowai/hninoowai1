<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {


	public function index()
	{
		$this->load->view('registeration');
	}
	public function addadmin()
	{
		# code...
		$name=$this->input->post('registername');
		$password=$this->input->post('registerpass');
		$studentaarray = array(
			'registername'=>$name,
			'registerpass'=>$password

		);

		$this->Ems_model->addadmin($studentaarray);

		$this->session->set_flashdata('login', '<div class="alert alert-success">
			<a href="#" class="close" data-dismiss="alert" aria-lable="close">&times;</a>
			<strong>
			Well done!
			</strong>
			New Expense is Added.!!
			</div>');


		redirect(base_url('Register'));

	}
}
