<!DOCTYPE html>
<html>
<head>
	<title>MyProject</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min."></script>
	<!-- onlineLink -->
    <link rel="stylesheet"href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

    <!-- onlineLink -->
	
</head>
<body>
<div><!-- thewhole -->
		<nav class="navbar navbar-inverse">
		  <div class="container-fluid">
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>                        
		      </button>
		      <a class="navbar-brand" href="<?php echo base_url(); ?>ems/loginview">Login</a>
		    </div>
		    <div class="collapse navbar-collapse" id="myNavbar">
		      <ul class="nav navbar-nav navbar-right">
			        <li class="dropdown">
 						<a class="dropdown-toggle" data-toggle="dropdown" href="admin_login.php"><span class="glyphicon glyphicon-user"></span>Login<span class="caret"></span></a>
 						<ul class="dropdown-menu">
 							<li><a href="#" class="home">LogOut</a></li>
 							<li><a href="#" class="home">Contact</a></li>
 							<li><a href="#" class="home">Service</a></li>
 						</ul>
 					</li>
		      </ul>
		    </div>
		  </div>
		</nav>

	<div class="row middle"><!-- middlepart -->

		<div class="col-sm-4 mid">
			<span class="glyphicon glyphicon-ok"></span>&nbsp;Dashboard
		</div>

		<div class="col-sm-8 coll">
			 <?php 

                echo $this->session->flashdata("login");
             
                ?>
			<h1 style="color: black;;">Student Registeration !</h1>
			<form  method="POST" action="<?php echo base_url(); ?>register/addadmin" role="form" enctype="multipart/form-data">
				<label class="la1">Name</label><br>
				<input type="text" name="registername" class="in1" required="required">
				<br>
				<label class="la1">Password</label><br>
				<input type="password" name="registerpass" class="in1" required="required">
				<br><br>
				<button onclick="HOW()" class="btn btn-primary add">Add</button>
			</form>
			
		</div>
	</div><!--end middlepart -->

</div><!--end thewhole -->
</body>
</html>