
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Bootstrap Admin Template</title>

    <!-- Bootstrap Core CSS -->
    <!-- onlineLink -->
    <link rel="stylesheet"href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

    <!-- onlineLink -->
    
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- PHPlinks -->
    <link href="<?php echo base_url('../css/bootstrap.min.css');?>" rel="stylesheet">
    <link href="<?php echo base_url('../css/sb-admin.css');?>" rel="stylesheet">

    <!-- PHPlinks -->

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
    .myinserttable tr td{
        border: 2px solid red;
        height: 50px;
        width: 50px;
        margin-left: auto;
        margin: 2px;
    }




</style>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php
                ">Exam System</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu message-dropdown">
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading"><strong>Admin</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading"><strong>Admin</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading"><strong>Admin</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-footer">
                            <a href="#">Read All New Messages</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Admin <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="#"><i class="fa fa-fw fa-user"></i> Profile</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-envelope"></i> Inbox</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-gear"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="<?php echo base_url(); ?>ems/logoutview"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="adminlist.php"><i class="fa fa-fw fa-dashboard"></i> Admin</a>
                    </li>
                    <li>
                        <a href="studentlist.php"><i class="fa fa-fw fa-bar-chart-o"></i> Students</a>
                    </li>
                    <li>
                        <a href="questionlist.php"><i class="fa fa-fw fa-table"></i> Question</a>
                    </li>
                    
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">
            <!-- Here is the admin INSERT form -->
            <div style="width: 300px; height: auto; margin: 2px; border: 4px solid gray; margin-top: 200px !important;">

                <?php 

                echo $this->session->flashdata("success");
                echo $this->session->flashdata("update");
                echo $this->session->flashdata("delete");
                ?>
                <form method="POST" action="<?php echo base_url(); ?>ems/addstudent" role="form" enctype="multipart/form-data">


                 <label>Username</label>
                 <input type="text" name="name" style="width: 200px; height: auto;"><br>

                 <label>Email</label>
                 <input type="text" name="email" style="width: 200px; height: auto;"><br>



                 <label>phone</label>
                 <input type="text" name="phone" style="width: 200px; height: auto;"><br>

                 <label>password</label>
                 <input type="text" name="password" style="width: 200px; height: auto;"><br>



             </form>
         </div>


         <!-- Here is Admin List -->
         <table class="myinserttable">
            <tr>
                <td> ID</td>
                <td> name</td>
                <td> email</td>
                <td> phone</td>
                <td> password</td>
                <td>Eidt</td>
                <td>Delete</td>
                
            </tr>

            <!-- tbody -->
            <?php

            $i=1;
            foreach ($studentlist as $row) {

                $id=$row->id;
                $name=$row->name;
                $email=$row->email;
                $phone=$row->phone;
                $password=$row->password;

                echo "<tr>
                <td>$id</td>
                <td>$name</td>
                <td>$email</td>
                <td>$phone</td>
                <td>$password</td>
                <td width='200px'><a href='#' class='btn btn-info update' data-toggle='modal' data-target='#myModal' data-id='$id' data-name='$name' data-email='$email' data-phone='$phone' data-password='$password'>Update</a>

                </td>
                <td>
                <a href=".base_url('.ems/delete/').$id." class='btn btn-danger'>Delete</a>
                </td>

                </tr>";
                $i++;
            }

            ?>

        </table>


    </div>
    <!-- /#page-wrapper -->


    <!-- Model for Edit form -->
    



      <!-- Modal -->
    <div class="container">
     <!-- <h2>Modal Example</h2> -->
          <!-- Trigger the modal with a button -->
          <!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button> -->
      <!-- Modal -->
      <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Modal Header</h4>
          </div>
          <div class="modal-body">
            <p><form method="POST" action="<?php echo base_url(); ?>ems/updatestudent" role="form" onsubmit="return check()" enctype="multipart/form-data">

                <input type="hidden" name="id" id="id">
             <label>Username</label>
             <input type="text" id="name" name="name" style="width: 200px; height: auto;"><br>

             <label>Email</label>
             <input type="text" id="email" name="email" style="width: 200px; height: auto;"><br>



             <label>phone</label>
             <input type="text" id="phone" name="phone" style="width: 200px; height: auto;"><br>

             <label>password</label>
             <input type="text" id="password" name="password" style="width: 200px; height: auto;"><br>



             <input type="submit" name="submit" value="Update Students">

         </form></p>
     </div>
     <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
  </div>
</div>

</div>
</div>






<!-- Modal -->


<!-- /#wrapper -->
<script type="text/javascript">
    $(document).ready(function(){
        $(".update").click(function(){
            var id=$(this).data("id");
            var name=$(this).data("name");
            var email=$(this).data("email");
            var phone=$(this).data("phone");
            var password=$(this).data("password");
                        ////////
                        $("#id").val(id);
                        $("#name").val(name);
                        $("#email").val(email);
                        $("#phone").val(phone);
                        $("#password").val(password);
                        $("#myModel").modal('show');


                    });
    });

</script>
<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="js/plugins/morris/raphael.min.js"></script>
<script src="js/plugins/morris/morris.min.js"></script>
<script src="js/plugins/morris/morris-data.js"></script>

</body>
</html>

