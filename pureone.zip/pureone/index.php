
<?php  
session_start();
require_once('database.php');
$database = new Database();

if (isset($_REQUEST['submit'])) {
	extract($_REQUEST);
	$login = $database->check_login($adminuser, $adminpass);
	if ($login) {
	        // Registration Success
		header("location:adminlist.php");
	} else {
	        // Registration Failed
		echo 'Wrong username or password';
	}
} 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Signin</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min."></script>

	<!-- Custom CSS -->
	<link href="css/sb-admin.css" rel="stylesheet">

	<!-- Morris Charts CSS -->
	<link href="css/plugins/morris.css" rel="stylesheet">

	<!-- Custom Fonts -->
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

	<div><!-- thewhole -->
		

		<div class="row middle"><!-- middlepart -->

			<div class="col-sm-4 mid">
				<span class="glyphicon glyphicon-ok"></span>&nbsp;Dashboard
			</div>

			<div class="col-sm-8 coll">
				<h1 style="color: #BDEEEE;;">Admin Login Form !</h1>
				<form action="#" method="POST">
					<label class="la1">Name</label><br>
					<input type="adminuser" name="adminuser" class="in1" required="required">
					<br>
					
					<label class="la1">Password</label><br>
					<input type="adminpass" name="adminpass" class="in1" required="required">
					<br><br>

					<a href=""><input type="submit" name="submit" class="btn btn-primary add" value="LOGIN"></a><br><br>
					<br><br><br>
					<a href="studentlogin.php" class="addd">student Login</a>
				</form><br><br>

				<a href="" class="for">F o r g o t  p a s s w o r d ? </a>

				
			</div>
		</div><!--end middlepart -->

	</div><!--end thewhole -->
</body>
</html>