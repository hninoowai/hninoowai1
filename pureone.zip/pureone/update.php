<?php
 require_once('database.php');
 $student_id = $_GET['student_id'];
 $ress = $database->read($student_id);
 $r = mysqli_fetch_assoc($ress);
 if(isset($_POST) & !empty($_POST)){
     $fullname = $database->sanitize($_POST['fullname']);
     $gender = $database->sanitize($_POST['gender']);
     $username = $database->sanitize($_POST['username']);
     $password = $database->sanitize($_POST['password']);
     $score = $database->sanitize($_POST['score']);
     $status = $database->sanitize($_POST['status']);
     $date = $database->sanitize($_POST['date']);
     $profileurl = $_POST['profileurl'];

    $ress = $database->update($fullname,$gender,$username,$password,$score,$status,$date,$profileurl,$student_id);
    if($ress){
        header("location:studentlist.php");
    }else{
        echo "failed to update data";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Bootstrap Admin Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
    .updateform input{
        color: #c53ec9;
    }
</style>
</head>

<body style="background-color: #f8effb;">
<div class="selena container" >
                        <p>Update Data</p>

                        <form role="form" method="POST" name="" action="" class="updateform">
                             <input type="text" name="fullname" value="<?php echo $r['fullname'] ?>"  class="namess form-control"><br><br>

                             <input type="text" name="gender" value="<?php echo $r['gender'] ?>"  class="namess form-control"><br><br>

                             <input type="text" name="username" value="<?php echo $r['username'] ?>"  class="namess form-control"><br><br>

                             <input type="text" name="password" value="<?php echo $r['password'] ?>"  class="namess form-control"><br><br>

                             <input type="text" name="score" value="<?php echo $r['score'] ?>"  class="namess form-control"><br><br>

                              <input type="text" name="status" value="<?php echo $r['status'] ?>"  class="namess form-control"><br><br>

                               <input type="text" name="date" value="<?php echo $r['date'] ?>"  class="namess form-control"><br><br>

                             
                             <input type="text" name="profileurl" value="<?php echo $r['profileurl'] ?>"  class="namess form-control"><br><br><br>
                            <button name="submit" type="submit">Update Now</button>

                        </form>

                    </div>


</body>
</html>