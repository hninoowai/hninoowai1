<?php
 require_once('database.php');
 $adminid = $_GET['adminid'];
 
 $res = $database->admin_delete($adminid);
 if($res){
 	header('location: adminlist.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>