<?php
 require_once('database.php');
 $student_id = $_GET['student_id'];
 
 $res = $database->delete($student_id);
 if($res){
 	header('location: studentlist.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>