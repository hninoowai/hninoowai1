<!DOCTYPE html>
<html>
<head>
	<title>Test For Html</title>
</head>
<body>
	<h1>Test for HTML</h1>

	<form method="post" action="#">
		<label>1. What does HTML stand for?</label><br><br>
		<input type="radio" name="ques">Hyper Text Markup Language<br>
		<input type="radio" name="ques">Hyperlinks and Text Markup Language<br>
		<input type="radio" name="ques">Home Tool Markup Language<br><br><br>

		<label>2. Who is making the Web standards?</label><br><br>
		<input type="radio" name="ques1">The World Wide Web Consortium<br>
		<input type="radio" name="ques1">Google<br>
		<input type="radio" name="ques1">Microsoft<br>
		<input type="radio" name="ques1">Mozilla<br><br><br>

		<label>3. Inline elements are normally displayed without starting a new line.</label><br><br>
		<input type="radio" name="ques2">TRUE<br>
		<input type="radio" name="ques2">FALSE<br><br><br>


		<label>4. Block elements are normally displayed without starting a new line.</label><br><br>
		<input type="radio" name="ques3">TRUE<br>
		<input type="radio" name="ques3">FALSE<br><br><br>


		<label>5. Which HTML attribute specifies an alternate text for an image, if the image cannot be displayed?</label><br><br>
		<input type="radio" name="ques">alt<br>
		<input type="radio" name="ques">src<br>
		<input type="radio" name="ques">longdesc<br>
		<input type="radio" name="ques">title<br><br><br>

		<label>1. What does HTML stand for?</label><br><br>
		<input type="radio" name="ques">Hyper Text Markup Language<br>
		<input type="radio" name="ques">Hyperlinks and Text Markup Language<br>
		<input type="radio" name="ques">Home Tool Markup Language<br><br><br>

		<label>1. What does HTML stand for?</label><br><br>
		<input type="radio" name="ques">Hyper Text Markup Language<br>
		<input type="radio" name="ques">Hyperlinks and Text Markup Language<br>
		<input type="radio" name="ques">Home Tool Markup Language<br><br><br>


		<label>1. What does HTML stand for?</label><br><br>
		<input type="radio" name="ques">Hyper Text Markup Language<br>
		<input type="radio" name="ques">Hyperlinks and Text Markup Language<br>
		<input type="radio" name="ques">Home Tool Markup Language<br><br><br>


		
	</form>
</body>
</html>