
<!DOCTYPE html>
<html>
<head>
	<title>html question</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="container" style="margin-top: 20px;">
		<div class="jumbotron" style="margin: 10px; padding: 20px;">
			<h2 style="width:auto;
			height: 50px;
			border-bottom: 3px solid red;
			">
				HTML quiz! 
			</h2>
		</div>
		<div class="alert alert-danger">

		<form>
			<label>1. What does HTML stand for?</label><br><br>
			<input type="radio" name="one"><label>Hyper Text Markup Language</label><br><br>
			<input type="radio" name="one"><label>Hyperlinks and Text Markup Language</label><br><br>
			<input type="radio" name="one"><label>Home Tool Markup Language</label><br>
		</form>
		</div>
		<div class="alert alert-danger">
		<form>
			<label>1. What does HTML stand for?</label><br><br>
			<input type="radio" name="two"><label>Hyper Text Markup Language</label><br><br>
			<input type="radio" name="two"><label>Hyperlinks and Text Markup Language</label><br><br>
			<input type="radio" name="two"><label>Home Tool Markup Language</label><br>
		</form>
		</div>
		<div class="alert alert-danger">
		<form>
			<label>1. What does HTML stand for?</label><br><br>
			<input type="radio" name="three"><label>Hyper Text Markup Language</label><br><br>
			<input type="radio" name="three"><label>Hyperlinks and Text Markup Language</label><br><br>
			<input type="radio" name="three"><label>Home Tool Markup Language</label><br>
		</form>
		</div>
		<div class="alert alert-danger">
		<form>
			<label>1. What does HTML stand for?</label><br><br>
			<input type="radio" name="four"><label>Hyper Text Markup Language</label><br>
			<input type="radio" name="four"><label>Hyperlinks and Text Markup Language</label><br>
			<input type="radio" name="four"><label>Home Tool Markup Language</label><br>
		</form>
		</div>
		<div class="alert alert-danger">
		<form>
			<label>1. What does HTML stand for?</label><br>
			<input type="radio" name="five"><label>Hyper Text Markup Language</label><br><br>
			<input type="radio" name="five"><label>Hyperlinks and Text Markup Language</label><br><br>
			<input type="radio" name="five"><label>Home Tool Markup Language</label><br>
		</form>
		</div>
		<div class="alert alert-danger">
		<form>
			<label>1. What does HTML stand for?</label><br>
			<input type="radio" name="six"><label>Hyper Text Markup Language</label><br><br>
			<input type="radio" name="six"><label>Hyperlinks and Text Markup Language</label><br><br>
			<input type="radio" name="six"><label>Home Tool Markup Language</label><br>
		</form>
		</div>
		<div class="alert alert-danger">
		<form>
			<label>1. What does HTML stand for?</label><br>
			<input type="radio" name="sevel"><label>Hyper Text Markup Language</label><br><br>
			<input type="radio" name="sevel"><label>Hyperlinks and Text Markup Language</label><br><br>
			<input type="radio" name="sevel"><label>Home Tool Markup Language</label><br>
		</form>
		</div>
		<div class="alert alert-danger">
		<form>
			<label>1. What does HTML stand for?</label><br>
			<input type="radio" name="eight"><label>Hyper Text Markup Language</label><br><br>
			<input type="radio" name="eight"><label>Hyperlinks and Text Markup Language</label><br><br>
			<input type="radio" name="eight"><label>Home Tool Markup Language</label><br>
		</form>
		</div>

		<button type="button" style="margin-bottom: 20px; background-color: red !important;" class="btn btn-primary btn-lg btn-block">Finish</button>
	</div>
</body>
</html>