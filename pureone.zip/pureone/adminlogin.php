<!-- 
 <?php  
  session_start();
	require_once('database.php');
	$database = new Database();

	if (isset($_REQUEST['submit'])) {
		extract($_REQUEST);
	    $login = $database->check_login($adminuser, $adminpass);
	    if ($login) {
	        // Registration Success
	       header("location:adminlist.php");
	    } else {
	        // Registration Failed
	        echo 'Wrong username or password';
	    }
	} 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Signin</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
<body>

	<div class="background">

	</div>

	<div class="bottom">

		<div class="color">
				
		</div>
			
		<div class="signup">
			<p>Admin Login</p>

			<form method="POST" name="" action="#">
				Name     : <input type="text" name="adminuser" class="names"><br><br>
				Password : <input type="password" name="adminpass" class="name"><br><br><br>
				<a href=""><input type="submit" name="submit" class="button-one" value="LOGIN"></a><br><br>

				
			</form>
			<a href="studentlogin.php"><button class="button-one">Student Login</button></a>

		</div>
	  
	</div>
</body>
</html> -->