<?php

class Database{
	
	private $connection;

	function __construct()
	{
		$this->connect_db();
	}

	public function connect_db(){
		$this->connection = mysqli_connect('localhost', 'root', '', 'pureone');
		if(mysqli_connect_error()){
			die("Database Connection Failed" . mysqli_connect_error() . mysqli_connect_errno());
		}
	}


	/*Create insert*/
	public function create($fullname,$gender,$username,$password,$score,$status,$date,$profileurl){
		$sql = "INSERT INTO `student_table` (fullname, gender, username, password, score, status, date, profileurl) VALUES ('$fullname', '$gender', '$username', '$password', '$score', '$status', '$date', '$profileurl')";
		$res = mysqli_query($this->connection, $sql);
		if($res){
	 		return true;
		}else{
			return false;
		}
	}

	/*question create*/
	public function creates($question,$option1,$option2,$option3,$answer){
		$sql = "INSERT INTO `question` (question, option1, option2, option3, answer) VALUES ('$question', '$option1', '$option2', '$option3', '$answer')";
		$result = mysqli_query($this->connection, $sql);
		if($result){
	 		return true;
		}else{
			return false;
		}
	}


	/*admin create*/
	public function admin_create($adminuser,$adminpass){
		$sql = "INSERT INTO `admin` (adminuser, adminpass) VALUES ('$adminuser', '$adminpass')";
		$result = mysqli_query($this->connection, $sql);
		if($result){
	 		return true;
		}else{
			return false;
		}
	}



	/*call data or read*/
	public function read($student_id=null){
		$sql = "SELECT * FROM `student_table`";
		if($student_id){ $sql .= " WHERE student_id=$student_id";}
 		$ress = mysqli_query($this->connection, $sql);
 		return $ress;
	}


	/*question read*/
	public function reads($question_id=null){
		$sql = "SELECT * FROM `question`";
		if($question_id){ $sql .= " WHERE question_id=$question_id";}
 		$resss = mysqli_query($this->connection, $sql);
 		return $resss;
	}


	/*admin read*/
	public function admin_read($adminid=null){
		$sql = "SELECT * FROM `admin`";
		if($adminid){ $sql .= " WHERE adminid=$adminid";}
 		$res_admin = mysqli_query($this->connection, $sql);
 		return $res_admin;
	}


	/*for call read*/
	



	/*update data*/
	public function update($fullname,$gender,$username,$password,$score,$status,$date,$profileurl,$student_id){
		$sql = "UPDATE `student_table` SET fullname='$fullname', gender='$gender', username='$username', password='$password', score='$score', status='$status', date='$date', profileurl='$profileurl' WHERE student_id=$student_id";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}


	/*update question*/
	public function updates($question,$option1,$option2,$option3,$answer,$question_id){
		$sql = "UPDATE `question` SET question='$question', option1='$option1', option2='$option2', option3='$option3', answer='$answer' WHERE question_id=$question_id";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}


	/*update admin*/
	public function admin_update($adminuser,$adminpass,$adminid){
		$sql = "UPDATE `admin` SET adminuser='$adminuser', adminpass='$adminpass' WHERE adminid=$adminid";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}



	/*delete data*/
	public function delete($student_id){
		$sql = "DELETE FROM `student_table` WHERE student_id=$student_id";
 		$res = mysqli_query($this->connection, $sql);
 		if($res){
 			return true;
 		}else{
 			return false;
 		}
	}

	/*delete question*/
	public function deletes($question_id){
		$sql = "DELETE FROM `question` WHERE question_id=$question_id";
 		$results = mysqli_query($this->connection, $sql);
 		if($results){
 			return true;
 		}else{
 			return false;
 		}
	}

	/*delete admin*/
	public function admin_delete($adminid){
		$sql = "DELETE FROM `admin` WHERE adminid=$adminid";
 		$res = mysqli_query($this->connection, $sql);
 		if($res){
 			return true;
 		}else{
 			return false;
 		}
	}


	public function sanitize($var){
		$return = mysqli_real_escape_string($this->connection, $var);
		return $return;
	}


	/*login*/
	public function check_login($adminuser, $adminpass){
 
           

	            $sql2="SELECT adminid FROM admin WHERE adminuser='$adminuser' and adminpass='$adminpass'";

	 

	            //checking if the username is available in the table

	            $result = mysqli_query($this->connection,$sql2);

	            $user_data = mysqli_fetch_array($result);

	            $count_row = $result->num_rows;

	 

	            if ($count_row == 1) {

	                // this login var will use for the session thing

	                $_SESSION['login'] = true;

	                $_SESSION['adminid'] = $user_data['adminid'];

	                return true;

	            }

	            else{

	                return false;

	            }

	        }

	 

	        /*** for showing the username or fullname ***/

	        public function get_fullname($adminid){

	            $sql3="SELECT adminuser FROM admin WHERE adminid = $adminid";

	            $result = mysqli_query($this->db,$sql3);

	            $user_data = mysqli_fetch_array($result);

	            echo $user_data['adminuser'];

	        }

	 

	        /*** starting the session ***/

	        public function get_session(){

	            return $_SESSION['login'];

	        }
	        public function user_logout() {
	        $_SESSION['login'] = FALSE;
	        session_destroy();
	    }


	    /*student login*/
	    public function student_login($studentname, $studentpass){
 
           

	            $sql4="SELECT studentid FROM student WHERE studentname='$studentname' and studentpass='$studentpass'";

	 

	            //checking if the username is available in the table

	            $result = mysqli_query($this->connection,$sql4);

	            $user_data = mysqli_fetch_array($result);

	            $count_row = $result->num_rows;

	 

	            if ($count_row == 1) {

	                // this login var will use for the session thing

	                $_SESSION['logins'] = true;

	                $_SESSION['studentid'] = $user_data['studentid'];

	                return true;

	            }

	            else{

	                return false;

	            }

	        }

	 

	        /*** for showing the username or fullname ***/

	        public function get_fullnames($studentid){

	            $sql5="SELECT studentname FROM student WHERE studentid = $studentid";

	            $result = mysqli_query($this->db,$sql5);

	            $user_data = mysqli_fetch_array($result);

	            echo $user_data['studentname'];

	        }

	 

	        /*** starting the session ***/

	        public function get_sessions(){

	            return $_SESSION['logins'];

	        }
	        public function student_logout() {
	        $_SESSION['logins'] = FALSE;
	        session_destroy();
	    }
       
}


$database = new Database();

?>