<?php  
session_start();
require_once('database.php');
$database = new Database();

if (isset($_REQUEST['submits'])) {
	extract($_REQUEST);
	$logins = $database->student_login($studentname, $studentpass);
	if ($logins) {
	        // Registration Success
		header("location:student_profile.php");
	} else {
	        // Registration Failed
		echo 'Wrong username or password';
	}
} 
?>

<!DOCTYPE html>
<html>
<head>
	<title>MyProject</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min."></script>
	
	
</head>
<body>
	<div><!-- thewhole -->
		<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>                        
					</button>
					<a class="navbar-brand" href="#">SMS Admin</a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>Admin<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="#" class="home">LogOut</a></li>
								<li><a href="#" class="home">Contact</a></li>
								<li><a href="#" class="home">Service</a></li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</nav>

		<div class="row middle"><!-- middlepart -->

			<div class="col-sm-4 mid">
				<span class="glyphicon glyphicon-ok"></span>&nbsp;Dashboard
			</div>

			<div class="col-sm-8 coll">
				<h1 style="color: #BDEEEE;;">student Login Form !</h1>
				<form method="POST" name="" action="#">
					<label class="la1">Name</label><br>
					<input type="text" name="studentname" class="in1" required="required">
					<br>
					<label class="la1">Password</label><br>
					<input type="password" name="studentpass" class="in1" required="required">
					<br><br>

					<a href=""><input type="submit" name="submits" class="btn btn-primary add" value="Login"></a> <br><br><br>

					<a href="index.php" class="addd">admin Login</a>
				</form><br><br>

				<a href="" class="for">F o r g o t  p a s s w o r d ? </a>


			</div>
		</div><!--end middlepart -->

	</div><!--end thewhole -->
</body>
</html>

