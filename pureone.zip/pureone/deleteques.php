<?php
 require_once('database.php');
 $question_id = $_GET['question_id'];
 
 $res = $database->deletes($question_id);
 if($res){
 	header('location: questionlist.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>