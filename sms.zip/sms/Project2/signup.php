<?php include ('dbconnect.php'); ?>
<?php
 	if($_SERVER['REQUEST_METHOD'] == 'POST'){
 		if(!empty($_POST['username'])){
 		$username = $_POST['username'];
 	}

 	if(!empty($_POST['password'])){
 		$password = $_POST['password'];
 	}
 	if($user->adduser($username,$password))
 	{
 		header("location:index.php");
 	}
 	else{
 		echo "ERROR";
 	}
 }
?>

<!DOCTYPE html>
<html>
<head>
	<title>signin</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min."></script>
	
</head>
<body>
	<div class="wholesignin">
	

		<div class="create_acc">
			<h1>Create New Account</h1>
			<form name="fbform" method="POST">
				<div class="apple">

				<div class="te 3">
					<input type="text" name="username" placeholder="Mobile Number or Email"></div><br>

				<div class="te 4">
					<input type="password" name="password" placeholder="New Password"></div> 
				<br>
				<button class="btn btn-success">Submit</button>
		</div>
	</form>


</div>
</body>
</html>