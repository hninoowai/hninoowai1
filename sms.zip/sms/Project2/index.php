<!DOCTYPE html>
<html>
<head>
	<title>Project 2</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min."></script>
</head>
<body>
<!-- The Whole -->
<div class="thewhole">
	<!-- TOP -->
	<div>
		
		<div>
			<img src="pics/korea7.jpg"  class="bgimg">
		</div>
		

		<div class="korea">
			<h1>Republic Of Korea</h1><br>
		</div>
		
		<!-- Navigation bar -->
		<div class="asia">
			<p>
			<a href="">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="">Asia</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="">World</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="">Korea</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="">About Us</a>
			</p>
			
		</div><!-- ENd Navigation -->
		<div>
			<h2 class="welcome">WELCOME TO KOREA!</h2>
		</div>
		<div>
			<h3 class="is">Korea is one of the most famous country in Asia..<br>
			Korea is famous of its beautiful traditional culture..</h3>
		</div>
		<div>
		<ul class="pager sign">
			<li><a href="signin.php">Sign Up</a></li>
		</ul>
		</div>

	</div><!-- END TOP -->

	<!-- MIDDLE -->
	<div class="middle">
		
		<div>
			<h2 class="all">About Korea</h2>
		</div>

		<div class="all">
			<h2 class="four">Korea is very famous for it..<span class="glyphicon glyphicon-arrow-down"></span></h2>
		</div>

		<div>
			<div class="pic1">
				<img src="pics/korea3.jpg" width="370px" height="180px" class="img1">
			</div>
			<div>
				<h4 class="palace">Gyeonbokgung Palace<br>

					In 1395, Gyeonbokgung Palace houses  <br>the Throne Hall,which stands as  <br>one of the most, iconic structures of <br>the Joseon Dynasty. It was the center<br> for essential state affairs as well as <br> storage for ancient Korean royal <br>books that were looted by the French military.
				</h4>
			</div>
		</div>
		<div>
			<div class="pic2">
				<img src="pics/kpop.jpg" width="370px" height="180px" class="img2">
			</div>
			<div class="best">
				<h4>Best KPOP Star in Korea<br>

					EXO is Quadruple Million Seller<br>
					EXO is Nation's pick..<br>
					They got Prime Master Award given by president<br>
					Their song(Power)was played in<br> Dubai Water Foutain..
				</h4>
			</div>
		</div>
		<div>
			<div class="pic3">
				<img src="pics/kimchiSoup.jpg" width="370px" height="180px">
			</div>
			<div>
				<h4 class="korean">
					Korean Food<br>

					Korean Food is becoming extremely popular.<br> Kimchi, bibimbap, and bulgogi are favored <br>by many around the world. Cuisine is an <br>important part of any culture and its popularity<br> automatically translates into more and <br>Smore interest in Korean culture.

				</h4>
			</div>
		</div>
	</div><!-- END MIDDLE -->

	<!--bottom  -->
	<div>
		<div>
			<h1 class="all">Wonderful Korea</h1>
		</div>
		<div>
			<h3 class="all">Some features Photos of Gyeonbokgung Palace</h3>
		</div>
		<div>
			<div class="pic4">
				<img src="pics/korea12.jpg" width="100px" height="100px">
			</div>
			<div>
				<h4 class="gyeon">Gyeonbokgung Palace<br><br>
					Gyeonbokgung Palace is the ancient building of Korea..<br>
					If you travell to Korea, you should come and visit here..
				</h4>
			</div>
		</div>
		<div>
			<div class="pic5">
				<img src="pics/korea11.jpg" width="100px" height="100px">
			</div>
			<div>
				<h4 class="gyeon">Gyeonbokgung Palace<br><br>
					Gyeonbokgung Palace is the ancient building of Korea..<br>
					If you travell to Korea, you should come and visit here..
				</h4>
			</div>
		</div>
		<div>
			<div class="pic6">
				<img src="pics/korea10.jpg" width="100px" height="100px">
			</div>
			<div>
				<h4 class="gyeonbo">Gyeonbokgung Palace<br><br>
					Gyeonbokgung Palace is the ancient building of Korea..<br>
					If you travell to Korea, you should come and visit here..
				</h4>
			</div>
		</div>
		<div>
			<div class="pic7">
				<img src="pics/korea4.jpg" width="100px" height="100px">
			</div>
			<div>
				<h4 class="gyeonbo">Gyeonbokgung Palace<br><br>
					Gyeonbokgung Palace is the ancient building of Korea..<br>
					If you travell to Korea, you should come and visit here..
				</h4>
			</div>
		</div>

	</div><!-- END BOTTOM -->

</div><!--End The Whole -->
</body>
</html>