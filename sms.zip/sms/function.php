<?php

class USER{
	private $db;
	function __construct($conn){
		$this->db = $conn;
	}

	public function getData($query){
		$stmt = $this->db->prepare($query);
		$stmt-> execute();
		$row=$stmt->fetchAll();
		return $row;
	}


	public function login($username, $password){


		try {
			$stmt = $this->db->prepare("SELECT * FROM admin WHERE username = :username LIMIT 1");
			$stmt->execute(array(':username'=>$username));
			$userRow = $stmt->fetch(PDO::FETCH_ASSOC);

			if ($stmt->rowCount() > 0) {
				if ($userRow['password'] == $password) {
					session_start();
					$_SESSION['username'] = $userRow['username'];
					$_SESSION['password'] = $userRow['password'];

					return true;
				}
				else {
					return false;
				}
			}

		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	public function logout(){
		session_destroy();
		return true;
	}

	public function addFeedback($normaluser,$email,$message){
	try {
			$stmt = $this->db->prepare("INSERT INTO contact(normaluser, email, message) VALUES (:normaluser, :email, :message)");


			$stmt->bindparam(":normaluser", $normaluser);
			$stmt->bindparam(":email", $email);
			$stmt->bindparam(":message", $message);


			$stmt->execute();
			return true;
		
		} 
		catch (PDOException $e) 
		{
			echo $e->getMessage();
			return false;
		}
	}

	public function addReservation($name,$mail,$phone,$person,$date,$time){
	try {
			$stmt = $this->db->prepare("INSERT INTO reservation(name,mail,phone,person,date,time) VALUES (:name, :mail, :phone, :person, :date, :time)");


			$stmt->bindparam(":name", $name);
			$stmt->bindparam(":mail", $mail);
			$stmt->bindparam(":phone", $phone);
			$stmt->bindparam(":person", $person);
			$stmt->bindparam(":date", $date);
			$stmt->bindparam(":time", $time);


			$stmt->execute();
			return true;
		
		} 
		catch (PDOException $e) 
		{
			echo $e->getMessage();
			return false;
		}
	}


}
?>
