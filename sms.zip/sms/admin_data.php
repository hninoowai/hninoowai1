<?php include ('dbconnect.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Hearty Fastfood</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php 
            include ('header.php');
        ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-md-12">
                        <h3>Reservation List</h3>
                        <!-- <a href="question_form.php"><button class="btn btn-info">Add</button></a> -->
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>Mail</th>
                                        <th>Phone</th>
                                        <th>Person</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                       
                                   </tr>
                                </thead>

                                <tbody>
                                   
                                   <?php 
                                    $query = "SELECT * FROM reservation";
                                    $data = $user->getData($query);
                                    $i=1;
                                    foreach($data as $row):
                                ?>
                                    <tr>
                                        <td><?php echo $row['no']?></td>
                                        <td><?php echo $row['name']?></td>
                                        <td><?php echo $row['mail']?></td>
                                        <td><?php echo $row['phone']?></td>
                                        <td><?php echo $row['person']?></td>
                                        <td><?php echo $row['date']?></td>
                                        <td><?php echo $row['time']?></td>

                                       </tr>
                                <?php 
                                    $i++;
                                    endforeach;
                                ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>
