<?php
require_once('database.php');
$res = $database->read();


session_start();

$database = new Database(); $adminid = $_SESSION['adminid'];
if (!$database->get_session()){
	header("location:index.php");
}

if (isset($_GET['q'])){
	$database->user_logout();
	header("location:index.php");
}

if(isset($_POST) & !empty($_POST)){
	$juice = $database->sanitize($_POST['juice']);
	$fruit = $database->sanitize($_POST['fruit']);
	$vegetable = $database->sanitize($_POST['vegetable']);
	$food = $database->sanitize($_POST['food']);

	$res = $database->create($juice,$fruit,$vegetable,$food);
	if($res){
		header("location:backend.php");
	}else{
		echo "failed to insert ";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min."></script>

</head>
<body>
	<div class="selena" >
		<p>Shopping List</p>

		<form class="formm" role="form" method="POST" name="" action="">
			<input type="text" name="juice" value="Juice" onfocus="this.value='';" onblur="if (this.value == ''){this.value= 'Juice';}" class="namess form-control"><br><br>

			<input type="text" name="fruit" value="Fruits" onfocus="this.value='';" onblur="if (this.value == ''){this.value= 'Fruits';}" class="namess form-control"><br><br>

			<input type="text" name="vegetable" value="Vegetables" onfocus="this.value='';" onblur="if (this.value == ''){this.value= 'Vegetables';}" class="namess form-control"><br><br>

			<input type="text" name="food" value="Other Foods" onfocus="this.value='';" onblur="if (this.value == ''){this.value= 'Other Foods';}" class="namess form-control"><br><br>

			<button name="submit" type="submit">Sign UP</button>

		</form>

	</div>




	<!-- Here is student List -->
	<h2 style="text-align: center; font-weight: bold;">Shopping List</h2>
	<table border="1px" style="margin-left: auto;margin-right: auto;">
		<tr>
			<td style="padding: 5px;">Number</td>
			<td style="padding: 5px;">Juice</td>
			<td style="padding: 5px;">Fruits</td>
			<td style="padding: 5px;">Vegetables</td>
			<td style="padding: 5px;">Other Foods</td>
			<td style="padding: 5px;">Edit/Delete</td>
		</tr>
		<?php 
		while($s = mysqli_fetch_assoc($res)){    
			?>
			<tr>
				<td style="padding: 5px;"><?php echo $s['food_id']?></td>
				<td style="padding: 5px;"><?php echo $s['juice']?></td>
				<td style="padding: 5px;"><?php echo $s['fruit']?></td>
				<td style="padding: 5px;"><?php echo $s['vegetable']?></td>
				<td style="padding: 5px;"><?php echo $s['food']?></td>
				<td style="padding: 5px;"><a href="update.php?food_id=<?php echo $s['food_id']; ?>">Edit</a> <a href="delete.php?food_id=<?php echo $s['food_id']; ?>">Delete</a></td>
			</tr>
			<?php 
		}
		?>





	</table>


</div>
<!-- /#page-wrapper -->

</div>
</body>
</html>