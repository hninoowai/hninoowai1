<?php

class Database{
	
	private $connection;

	function __construct()
	{
		$this->connect_db();
	}

	public function connect_db(){
		$this->connection = mysqli_connect('localhost', 'root', '', 'puretwo');
		if(mysqli_connect_error()){
			die("Database Connection Failed" . mysqli_connect_error() . mysqli_connect_errno());
		}
	}


	/*Create insert*/
	public function create($juice,$fruit,$vegetable,$food){
		$sql = "INSERT INTO `food` (juice, fruit, vegetable, food) VALUES ('$juice', '$fruit', '$vegetable', '$food')";
		$res = mysqli_query($this->connection, $sql);
		if($res){
	 		return true;
		}else{
			return false;
		}
	}




	/*call data or read*/
	public function read($food_id=null){
		$sql = "SELECT * FROM `food`";
		if($food_id){ $sql .= " WHERE food_id=$food_id";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}



	/*update data*/
	public function update($juice,$fruit,$vegetable,$food,$food_id){
		$sql = "UPDATE `food` SET juice='$juice', fruit='$fruit', vegetable='$vegetable', food='$food' WHERE food_id=$food_id";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}


	/*delete data*/
	public function delete($food_id){
		$sql = "DELETE FROM `food` WHERE food_id=$food_id";
 		$res = mysqli_query($this->connection, $sql);
 		if($res){
 			return true;
 		}else{
 			return false;
 		}
	}


	public function sanitize($var){
		$return = mysqli_real_escape_string($this->connection, $var);
		return $return;
	}


	/*login*/
	public function check_login($username, $password){
 
           

	            $sql2="SELECT adminid FROM customer WHERE username='$username' and password='$password'";

	 

	            //checking if the username is available in the table

	            $result = mysqli_query($this->connection,$sql2);

	            $user_data = mysqli_fetch_array($result);

	            $count_row = $result->num_rows;

	 

	            if ($count_row == 1) {

	                // this login var will use for the session thing

	                $_SESSION['login'] = true;

	                $_SESSION['adminid'] = $user_data['adminid'];

	                return true;

	            }

	            else{

	                return false;

	            }

	        }

	 

	        /*** for showing the username or fullname ***/

	        public function get_fullname($adminid){

	            $sql3="SELECT username FROM customer WHERE adminid = $adminid";

	            $result = mysqli_query($this->db,$sql3);

	            $user_data = mysqli_fetch_array($result);

	            echo $user_data['username'];

	        }

	 

	        /*** starting the session ***/

	        public function get_session(){

	            return $_SESSION['login'];

	        }
	        public function user_logout() {
	        $_SESSION['login'] = FALSE;
	        session_destroy();
	    }


	   

}

$database = new Database();

?>