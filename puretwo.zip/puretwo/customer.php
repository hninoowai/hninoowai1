
<?php  
session_start();
require_once('database.php');
$database = new Database();

if (isset($_REQUEST['submit'])) {
	extract($_REQUEST);
	$login = $database->check_login($username, $password);
	if ($login) {
	        // Registration Success
		header("location:backend.php");
	} else {
	        // Registration Failed
		echo 'Wrong username or password';
	}
} 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Signin</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min."></script>


</head>
<body>


	<div class="">


		<div class="tom">
			<h1>Customer Login Form !</h1>
			<form action="#" method="POST">
				<label class="">Name</label><br>
				<input type="username" name="username" class="in1" required="required" class="in">
				<br>

				<label class="">Password</label><br>
				<input type="password" name="password" class="in1" required="required" class="in">
				<br><br>

				<a href=""><input type="submit" name="submit" class="btn btn-primary add" value="LOGIN"></a><br><br>
				
			</div>
		</div>

	
</body>
</html>