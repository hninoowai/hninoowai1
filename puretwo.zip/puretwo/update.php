<?php
require_once('database.php');
$food_id = $_GET['food_id'];
$ress = $database->read($food_id);
$r = mysqli_fetch_assoc($ress);
if(isset($_POST) & !empty($_POST)){
    $juice = $database->sanitize($_POST['juice']);
   $fruit = $database->sanitize($_POST['fruit']);
   $vegetable = $database->sanitize($_POST['vegetable']);
   $food = $database->sanitize($_POST['food']);
   

   $ress = $database->update($juice,$fruit,$vegetable,$food,$food_id);
   if($ress){
    header("location:backend.php");
}else{
    echo "failed to update data";
}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Bootstrap Admin Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    
</head>

<body style="background-color: #f8effb;">
    <div class="selena container" >
        <p>Update Food</p>

        <form role="form" method="POST" name="" action="" class="updateform">
            <input type="text" name="juice" value="<?php echo $r['juice'] ?>"  class="namess form-control"><br><br>

           <input type="text" name="fruit" value="<?php echo $r['fruit'] ?>"  class="namess form-control"><br><br>

           <input type="text" name="vegetable" value="<?php echo $r['vegetable'] ?>"  class="namess form-control"><br><br>

           <input type="text" name="food" value="<?php echo $r['food'] ?>"  class="namess form-control"><br><br>

           <button name="submit" type="submit">Update Now</button>

       </form>

   </div>


</body>
</html>