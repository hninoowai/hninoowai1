<?php
 require_once('database.php');
 $food_id = $_GET['food_id'];
 
 $res = $database->delete($food_id);
 if($res){
 	header('location: backend.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>