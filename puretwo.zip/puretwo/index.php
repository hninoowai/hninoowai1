
<!DOCTYPE html>
<html>
<head>
	<title>Online Shop</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min."></script>
</head>
<body>
	<div>
		<div class="welcome"><marquee class="directon left"><h1 class="">Welcome To Online Shopping!!!!</h1></marquee></div>
		<div class="to"><h3>Plz login to Buy..</h3>
		</div>
		<div class="cus"><a href="customer.php">Click Here To Fill Customer Login Form</a></div>

	</div>
</body>
</html>